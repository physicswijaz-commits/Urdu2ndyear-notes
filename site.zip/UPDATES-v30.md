# v30
- Header, drawer (≡) and floating dock now follow Mutalea Quran: ≡ at right, title+subtitle, left pill (night/day + back), drawer with pages / this lesson's contents / settings (theme, font, focus). Lesson pages get a سبق | مشق dock. Cache v30.
