# v45
- New app icon: burgundy background, cream bookmark "alif" with four right-to-left text lines and a gold nuqta dot.
- Service-worker cache bumped to v45.
- Remove the old home-screen app and add it again to see the new icon.
