# v31
- Compact header/dock, fixed clipped title descenders; مشق section in poems/ghazals no longer boxed (full-width question cards); per-section colours (نثر green, نظم blue, غزل plum) and icons (scroll-text, feather, flower-2); lesson pages inherit their section colour. Cache v31.
