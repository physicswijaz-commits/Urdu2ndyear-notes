# v28
- Colors back to the Mutalea Quran palette (v27 slate removed).
- MQ-style footer on every page: Made with ♥ by M. Ijaz (-> me), ہمارے بارے میں / رازداری / استعمال کی شرائط, © 2026. New about.html.
- Removed the 'غلطی بتائیں' link. Cache v28.
