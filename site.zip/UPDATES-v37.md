# v37
- Home top: search box sits in the header row (≡ | search | night-day), title row removed; hero trimmed to one row of chips; exam card is a slim centered line. Cache v37.
