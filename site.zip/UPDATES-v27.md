# v27
- Palette changed to cool slate-blue / steel grey with pale-blue selected cards (light, dark, sepia). Cache v27.
