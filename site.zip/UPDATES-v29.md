# v29
- Rebuilt me.html in the Mutalea Quran layout: photo + name row, 3 stat cards, short sections (intro, goals, projects, note to readers), clear contact buttons.
- Removed the old 'Created by M.ijaz' watermark (footer already credits). Cache v29.
