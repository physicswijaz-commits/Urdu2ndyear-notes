# v35
- Home compacted: exam-date card is one slim row, الفاظ/فلیش کارڈز are two small tiles, streak widget is a single line, smaller hero. Cache v35.
