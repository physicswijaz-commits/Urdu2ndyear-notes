# v38
- Drawer order: this lesson's contents + مشق first, then سیٹنگز, then صفحات at the very bottom. Cache v38.
