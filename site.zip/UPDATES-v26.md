# v26
- Removed the سبق/مشق tab cards and the dark banner boxes; lesson top = chapter title + author as plain text; header bar shows the chapter name.
- "سبق مکمل کریں" now sits at the end of the lesson (big button, like MQ), with "مشق کھولیں / سبق پر واپس" below; reading-time chip removed.
- Palette = Mutalea Quran's calm sage/white (low glare) in light, dark and sepia.
- Cache v26.
