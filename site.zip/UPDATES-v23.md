# v23 — Privacy pages + "Manuscript" redesign
- New: privacy.html (پرائیویسی پالیسی) and terms.html (شرائط و ضوابط), linked from footers and the access gate; precached offline.
- Redesign (CSS-only layer at end of style.css, markup & lesson text untouched): star-lattice paper background, emerald banners with gold hairline, round number chips, gold ornament section titles, ❖ lesson headings, floating pill tab-bar, softer cards, ornamental footer.
- Service worker cache: v23.
