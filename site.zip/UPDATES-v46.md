# v46
- App icon now shows the word "اردو" in large lettering on burgundy, with a bookmark ribbon and text lines, so it is recognizable as the Urdu app.
- Service-worker cache bumped to v46.
