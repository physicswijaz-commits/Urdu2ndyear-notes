# v39
- New app icon (emerald, open book with gold star and bookmark) in all sizes + favicon link on every page. Cache v39.
