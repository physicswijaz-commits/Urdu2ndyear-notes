# v32
- Lesson header shows only 'سبق 1 · نثر · گروپ A' (chapter name appears once, in the page heading). Removed the 'میں' tab from the bottom bar (still in menu and footer). Cache v32.
