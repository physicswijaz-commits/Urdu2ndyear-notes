# v24 — Layout rearrangement
- Header: theme / font size / focus mode / practice now sit in one "دکھاوٹ" settings panel (button at the header end).
- Lesson pages: two cards under the banner — سبق (original text) and مشق (Q&A, vocabulary, answer skeleton). Deep links (#qa, #vocab, #mushq, sidebar) switch tabs automatically.
- Home: every chapter row has سبق and مشق buttons; bottom tab bar added to home; 5th tab "میں".
- New me.html (about me, photo, contact). Unified footer (me / privacy / terms).
- Removed the print/PDF button.
- Cache v24.
