/* ==========================================================================
   خود آزمائی موڈ (Self-quiz mode)
   Works on the existing سوالات و جوابات (Q&A) cards already written into
   each lesson — no new/invented questions. For every Q&A card you can mark
   "پتا ہے" (I know this) or "سیکھ رہا ہوں" (still learning) after reading
   the answer. A summary bar tracks counts per lesson, and a filter can hide
   the ones you already know so revision focuses on what's left.
   State is stored in localStorage, per lesson page, under 'quizState'.
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {

  const allCards = Array.from(document.querySelectorAll('.qa-card'));
  if (!allCards.length) return; // this page has no Q&A section — nothing to do

  const page = location.pathname.split('/').pop();

  /* ---------- localStorage: { [page]: { [cardIndex]: 'know' | 'learning' } } ---------- */
  function getAllState() {
    try { return JSON.parse(localStorage.getItem('quizState') || '{}'); }
    catch (e) { return {}; }
  }
  function getPageState() {
    return getAllState()[page] || {};
  }
  function setMark(index, mark) {
    const all = getAllState();
    const pageState = all[page] || {};
    if (pageState[index] === mark) delete pageState[index]; /* tap again to clear */
    else pageState[index] = mark;
    all[page] = pageState;
    localStorage.setItem('quizState', JSON.stringify(all));
    return pageState;
  }

  /* Group Q&A cards by their container section, since نثر uses
     <section id="qa"> and نظم/غزل use <section id="mushq"> — either way,
     each container gets exactly one summary bar above its own cards. */
  const containers = [];
  allCards.forEach((card) => {
    const container = card.parentElement;
    if (container && !containers.includes(container)) containers.push(container);
  });

  let globalIndex = 0; /* unique index per card across the whole page, for storage keys */
  let filterActive = false;

  containers.forEach((container) => {
    const cards = Array.from(container.children).filter((el) => el.classList.contains('qa-card'));
    if (!cards.length) return;
    const heading = container.querySelector('h2');

    const summary = document.createElement('div');
    summary.className = 'quiz-summary';
    const knowLabelId = 'quiz-know-' + globalIndex;
    const learningLabelId = 'quiz-learning-' + globalIndex;
    summary.innerHTML =
      '<div class="quiz-summary-stat"><b id="' + knowLabelId + '">0</b><span>پتا ہے</span></div>' +
      '<div class="quiz-summary-stat"><b id="' + learningLabelId + '">0</b><span>سیکھ رہا ہوں</span></div>' +
      '<button type="button" class="quiz-filter-btn">صرف سیکھنے والے</button>';
    if (heading) heading.insertAdjacentElement('afterend', summary);
    else container.insertBefore(summary, container.firstChild);

    const knowCountEl = summary.querySelector('#' + knowLabelId);
    const learningCountEl = summary.querySelector('#' + learningLabelId);
    const filterBtn = summary.querySelector('.quiz-filter-btn');

    const cardEntries = cards.map((card) => {
      const index = globalIndex++;
      const question = card.querySelector('.qa-question');
      const answer = card.querySelector('.qa-answer');
      if (!question || !answer) return null;

      const badge = document.createElement('span');
      badge.className = 'quiz-badge';
      badge.style.display = 'none';
      const toggle = question.querySelector('.q-toggle');
      if (toggle) question.insertBefore(badge, toggle);
      else question.appendChild(badge);

      const markRow = document.createElement('div');
      markRow.className = 'quiz-mark-row';
      markRow.innerHTML =
        '<button type="button" class="quiz-mark-btn quiz-mark-know"><i data-lucide="check"></i>پتا ہے</button>' +
        '<button type="button" class="quiz-mark-btn quiz-mark-learning"><i data-lucide="rotate-ccw"></i>سیکھ رہا ہوں</button>';
      answer.appendChild(markRow);

      const knowBtn = markRow.querySelector('.quiz-mark-know');
      const learningBtn = markRow.querySelector('.quiz-mark-learning');

      function render(mark) {
        knowBtn.classList.toggle('active', mark === 'know');
        learningBtn.classList.toggle('active', mark === 'learning');
        badge.classList.remove('quiz-badge-know', 'quiz-badge-learning');
        if (mark === 'know') {
          badge.classList.add('quiz-badge-know'); badge.textContent = '✓'; badge.style.display = '';
        } else if (mark === 'learning') {
          badge.classList.add('quiz-badge-learning'); badge.textContent = '•'; badge.style.display = '';
        } else {
          badge.style.display = 'none'; badge.textContent = '';
        }
        card.classList.toggle('quiz-hidden', filterActive && mark === 'know');
      }

      [knowBtn, learningBtn].forEach((btn, i) => {
        const mark = i === 0 ? 'know' : 'learning';
        btn.addEventListener('click', (e) => {
          e.stopPropagation(); /* don't also trigger the accordion toggle */
          const updated = setMark(index, mark);
          render(updated[index]);
          updateSummary();
        });
      });

      render(getPageState()[index]);
      return { card, index, render };
    }).filter(Boolean);

    function updateSummary() {
      const state = getPageState();
      let know = 0, learning = 0;
      cardEntries.forEach(({ index }) => {
        if (state[index] === 'know') know++;
        else if (state[index] === 'learning') learning++;
      });
      knowCountEl.textContent = know;
      learningCountEl.textContent = learning;
    }

    filterBtn.addEventListener('click', () => {
      filterActive = !filterActive;
      filterBtn.classList.toggle('active', filterActive);
      filterBtn.textContent = filterActive ? 'سب دکھائیں' : 'صرف سیکھنے والے';
      const state = getPageState();
      cardEntries.forEach(({ card, index }) => {
        card.classList.toggle('quiz-hidden', filterActive && state[index] === 'know');
      });
    });

    updateSummary();
  });

  if (window.lucide) lucide.createIcons();
});
