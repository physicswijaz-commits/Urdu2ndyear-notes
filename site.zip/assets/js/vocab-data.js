/* ==========================================================================
   اردو دوم سال — Vocabulary Bank data
   Auto-collected from the "الفاظ کے معانی" tables/boxes in every نثر، نظم
   and غزل lesson. Regenerate by re-running extract_vocab.py if lesson
   content changes.
   ========================================================================== */
const VOCAB_CORE = [
  {
    "word": "تصنیف و تالیف",
    "meaning": "کتابیں لکھنا اور مختلف حوالوں سے جمع کر کے مرتب کرنا",
    "chapter": 1,
    "chapterTitle": "مسلمانوں کا قدیم طرزِ تعلیم",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "عقلی علوم",
    "meaning": "وہ علم جو عقل اور دلیل پر مبنی ہوں، جیسے فلسفہ اور منطق",
    "chapter": 1,
    "chapterTitle": "مسلمانوں کا قدیم طرزِ تعلیم",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "اسماء الرجال",
    "meaning": "وہ علم جس میں حدیث بیان کرنے والے راویوں کی زندگی اور حالات کا ذکر ہو",
    "chapter": 1,
    "chapterTitle": "مسلمانوں کا قدیم طرزِ تعلیم",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "املاء",
    "meaning": "استاد کا زبانی بولنا اور طلباء کا اسے لکھنا",
    "chapter": 1,
    "chapterTitle": "مسلمانوں کا قدیم طرزِ تعلیم",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "امالی",
    "meaning": "وہ کتابیں جو استاد کے املاء کروانے سے طلباء نے جمع کی ہوں",
    "chapter": 1,
    "chapterTitle": "مسلمانوں کا قدیم طرزِ تعلیم",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "مناظرہ",
    "meaning": "دو یا زیادہ لوگوں کے درمیان کسی علمی مسئلے پر دلیل کے ساتھ بحث و مباحثہ",
    "chapter": 1,
    "chapterTitle": "مسلمانوں کا قدیم طرزِ تعلیم",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "طیلسان",
    "meaning": "ایک خاص قسم کا لباس یا چادر جو تعلیم مکمل ہونے پر پہنائی جاتی تھی",
    "chapter": 1,
    "chapterTitle": "مسلمانوں کا قدیم طرزِ تعلیم",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "موشگافیاں",
    "meaning": "کسی چیز میں غیر ضروری باریکیاں نکالنا یا بلاوجہ گہرائی میں جانا",
    "chapter": 1,
    "chapterTitle": "مسلمانوں کا قدیم طرزِ تعلیم",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "اوقاف",
    "meaning": "وہ جائیدادیں جو اللہ کے نام پر یا کسی فلاحی کام کے لیے وقف کر دی گئی ہوں",
    "chapter": 1,
    "chapterTitle": "مسلمانوں کا قدیم طرزِ تعلیم",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "رصد خانے",
    "meaning": "وہ جگہیں جہاں سے ستاروں اور سیاروں کا مشاہدہ کیا جاتا ہے",
    "chapter": 1,
    "chapterTitle": "مسلمانوں کا قدیم طرزِ تعلیم",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "حکماء",
    "meaning": "دانا اور عقل مند لوگ، فلسفی",
    "chapter": 2,
    "chapterTitle": "سقراط",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "بت تراش",
    "meaning": "مورتیاں یا مجسمے بنانے والا کاریگر",
    "chapter": 2,
    "chapterTitle": "سقراط",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "استقلال",
    "meaning": "مضبوط ارادہ، ثابت قدمی",
    "chapter": 2,
    "chapterTitle": "سقراط",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "پشیمانی",
    "meaning": "افسوس، شرمندگی",
    "chapter": 2,
    "chapterTitle": "سقراط",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "سوانح عمری",
    "meaning": "کسی کی زندگی کے حالات پر لکھی گئی کتاب",
    "chapter": 2,
    "chapterTitle": "سقراط",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "بردباری",
    "meaning": "صبر اور تحمل",
    "chapter": 2,
    "chapterTitle": "سقراط",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "ضمیر",
    "meaning": "انسان کے اندر کی وہ آواز جو صحیح اور غلط میں فرق بتاتی ہے",
    "chapter": 2,
    "chapterTitle": "سقراط",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "جمادات",
    "meaning": "وہ چیزیں جن میں جان نہ ہو، یعنی بے حس چیزیں",
    "chapter": 2,
    "chapterTitle": "سقراط",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "تاراج",
    "meaning": "تباہ و برباد",
    "chapter": 3,
    "chapterTitle": "فاقہ میں روزہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "مصاحب",
    "meaning": "ساتھی، درباری",
    "chapter": 3,
    "chapterTitle": "فاقہ میں روزہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "ندیم",
    "meaning": "ہم نشین، قریبی دوست",
    "chapter": 3,
    "chapterTitle": "فاقہ میں روزہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "فاقہ",
    "meaning": "بھوکا رہنا، کھانے کو کچھ نہ ہونا",
    "chapter": 3,
    "chapterTitle": "فاقہ میں روزہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "نازونعمت",
    "meaning": "آرام اور آسائش کی زندگی",
    "chapter": 3,
    "chapterTitle": "فاقہ میں روزہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "تُف ہے",
    "meaning": "دھتکار اور شرمندگی کا اظہار، افسوس کا کلمہ",
    "chapter": 3,
    "chapterTitle": "فاقہ میں روزہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "غیرت داری",
    "meaning": "خودداری، عزتِ نفس کا خیال رکھنا",
    "chapter": 3,
    "chapterTitle": "فاقہ میں روزہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "بین کرنا",
    "meaning": "رو رو کر افسوس کرنا، نوحہ کرنا",
    "chapter": 3,
    "chapterTitle": "فاقہ میں روزہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "لق و دق",
    "meaning": "بالکل ویران اور سنسان (جنگل یا میدان)",
    "chapter": 3,
    "chapterTitle": "فاقہ میں روزہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "آتشناک",
    "meaning": "آگ برساتا ہوا",
    "chapter": 3,
    "chapterTitle": "فاقہ میں روزہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "جولان گاہ",
    "meaning": "گھومنے پھرنے کی جگہ، میدانِ عمل",
    "chapter": 3,
    "chapterTitle": "فاقہ میں روزہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "وطنیت",
    "meaning": "کسی خاص زمین یا علاقے سے وابستگی کا جذبہ",
    "chapter": 4,
    "chapterTitle": "پھر وطنیت کی طرف",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "وحدتِ ملّت",
    "meaning": "دنیا بھر کے مسلمانوں کے ایک قوم ہونے کا احساس",
    "chapter": 4,
    "chapterTitle": "پھر وطنیت کی طرف",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "نصب العین",
    "meaning": "مقصد، منزل، جس کے حصول کی کوشش کی جائے",
    "chapter": 4,
    "chapterTitle": "پھر وطنیت کی طرف",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "رجعت",
    "meaning": "پیچھے ہٹنا، واپس لوٹنا",
    "chapter": 4,
    "chapterTitle": "پھر وطنیت کی طرف",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "آفاقی",
    "meaning": "عالمگیر، ساری دنیا پر محیط",
    "chapter": 4,
    "chapterTitle": "پھر وطنیت کی طرف",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "برِ عظیم",
    "meaning": "بہت بڑا خطۂ زمین، جیسے برصغیر",
    "chapter": 4,
    "chapterTitle": "پھر وطنیت کی طرف",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "بہرہ مند",
    "meaning": "فائدہ اٹھانے والا",
    "chapter": 4,
    "chapterTitle": "پھر وطنیت کی طرف",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "فوزِ عظیم",
    "meaning": "بہت بڑی کامیابی",
    "chapter": 4,
    "chapterTitle": "پھر وطنیت کی طرف",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "بقائے دوام",
    "meaning": "ہمیشہ کے لیے باقی رہنا، دائمی شہرت",
    "chapter": 5,
    "chapterTitle": "شہرتِ عام اور بقائے دوام کا دربار",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "شہرتِ عام",
    "meaning": "وقتی اور ظاہری مقبولیت",
    "chapter": 5,
    "chapterTitle": "شہرتِ عام اور بقائے دوام کا دربار",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "تمثیل",
    "meaning": "علامتی کہانی، جس میں بات کو کسی اور شکل میں بیان کیا جائے",
    "chapter": 5,
    "chapterTitle": "شہرتِ عام اور بقائے دوام کا دربار",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "زیرک",
    "meaning": "ہوشیار، عقل مند",
    "chapter": 5,
    "chapterTitle": "شہرتِ عام اور بقائے دوام کا دربار",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "حبّ الوطن",
    "meaning": "وطن سے محبت رکھنے والا",
    "chapter": 5,
    "chapterTitle": "شہرتِ عام اور بقائے دوام کا دربار",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "طورۂ چنگیزی",
    "meaning": "چنگیز خان کے مقرر کردہ ملکی قوانین و ضابطے",
    "chapter": 5,
    "chapterTitle": "شہرتِ عام اور بقائے دوام کا دربار",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "تمکنت",
    "meaning": "وقار، شان و شوکت",
    "chapter": 5,
    "chapterTitle": "شہرتِ عام اور بقائے دوام کا دربار",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "فصاحت و بلاغت",
    "meaning": "زبان کی خوبصورتی اور مؤثر انداز میں بات کہنے کا ہنر",
    "chapter": 5,
    "chapterTitle": "شہرتِ عام اور بقائے دوام کا دربار",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "میدانِ وسیع الفضا",
    "meaning": "بہت کھلا اور وسیع میدان",
    "chapter": 5,
    "chapterTitle": "شہرتِ عام اور بقائے دوام کا دربار",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "انبوہ",
    "meaning": "بھیڑ، ہجوم",
    "chapter": 5,
    "chapterTitle": "شہرتِ عام اور بقائے دوام کا دربار",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "غول",
    "meaning": "لوگوں کا جھنڈ یا گروہ",
    "chapter": 5,
    "chapterTitle": "شہرتِ عام اور بقائے دوام کا دربار",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "ہاتف",
    "meaning": "غیبی آواز",
    "chapter": 5,
    "chapterTitle": "شہرتِ عام اور بقائے دوام کا دربار",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "اصطرلاب",
    "meaning": "ستاروں کی پیمائش کا قدیم آلہ",
    "chapter": 5,
    "chapterTitle": "شہرتِ عام اور بقائے دوام کا دربار",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "درفشِ کاویانی",
    "meaning": "ایران کا قدیم شاہی جھنڈا",
    "chapter": 5,
    "chapterTitle": "شہرتِ عام اور بقائے دوام کا دربار",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "خدائی لشکر",
    "meaning": "بہت بڑا اور شاندار لشکر",
    "chapter": 5,
    "chapterTitle": "شہرتِ عام اور بقائے دوام کا دربار",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "قصاب",
    "meaning": "گوشت کاٹنے والا، یہاں مراد بے رحم شخص",
    "chapter": 5,
    "chapterTitle": "شہرتِ عام اور بقائے دوام کا دربار",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "مصور",
    "meaning": "تصویر بنانے والا، یہاں مراد خیال کو الفاظ میں پیش کرنے والا شاعر",
    "chapter": 5,
    "chapterTitle": "شہرتِ عام اور بقائے دوام کا دربار",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "دانا",
    "meaning": "عقل مند، سمجھ دار",
    "chapter": 5,
    "chapterTitle": "شہرتِ عام اور بقائے دوام کا دربار",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "خلعتِ خونی",
    "meaning": "خون میں لتھڑا لباس، یعنی جنگ میں شہادت",
    "chapter": 5,
    "chapterTitle": "شہرتِ عام اور بقائے دوام کا دربار",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "بزمِ تحقیق",
    "meaning": "علمی تحقیق کی مجلس",
    "chapter": 5,
    "chapterTitle": "شہرتِ عام اور بقائے دوام کا دربار",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "قوی الجثہ",
    "meaning": "بہت بڑے جسم والا، طاقتور",
    "chapter": 6,
    "chapterTitle": "چند روز ایک روڈ رولر کے ساتھ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "دیو ہیکل",
    "meaning": "دیو جیسا بہت بڑا جسم رکھنے والا",
    "chapter": 6,
    "chapterTitle": "چند روز ایک روڈ رولر کے ساتھ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "معیت",
    "meaning": "ساتھ، ہمراہی",
    "chapter": 6,
    "chapterTitle": "چند روز ایک روڈ رولر کے ساتھ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "عجوبۂ روزگار",
    "meaning": "زمانے کا انوکھا اور حیران کن نمونہ",
    "chapter": 6,
    "chapterTitle": "چند روز ایک روڈ رولر کے ساتھ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "اسپ تازی",
    "meaning": "تیز رفتار گھوڑا",
    "chapter": 6,
    "chapterTitle": "چند روز ایک روڈ رولر کے ساتھ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "ہست",
    "meaning": "وجود، ہونا",
    "chapter": 6,
    "chapterTitle": "چند روز ایک روڈ رولر کے ساتھ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "لرزہ براندام",
    "meaning": "کانپتا ہوا، لرزتا ہوا",
    "chapter": 6,
    "chapterTitle": "چند روز ایک روڈ رولر کے ساتھ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "عملِ معکوس",
    "meaning": "الٹا عمل، برعکس ردِعمل",
    "chapter": 6,
    "chapterTitle": "چند روز ایک روڈ رولر کے ساتھ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "بل بتوڑی",
    "meaning": "چھوٹے الو کی مادہ",
    "chapter": 6,
    "chapterTitle": "چند روز ایک روڈ رولر کے ساتھ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "خرامی",
    "meaning": "آہستہ اور نپے تلے قدموں سے چلنا",
    "chapter": 6,
    "chapterTitle": "چند روز ایک روڈ رولر کے ساتھ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "انتشار",
    "meaning": "بکھراؤ، پریشانی",
    "chapter": 6,
    "chapterTitle": "چند روز ایک روڈ رولر کے ساتھ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "مراقبہ/سمادھی",
    "meaning": "دھیان لگانے کی حالت، گہرا تصور",
    "chapter": 6,
    "chapterTitle": "چند روز ایک روڈ رولر کے ساتھ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "مہین غلاف",
    "meaning": "باریک پردہ یا خول",
    "chapter": 6,
    "chapterTitle": "چند روز ایک روڈ رولر کے ساتھ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "تحویل",
    "meaning": "قبضہ، ملکیت میں لینا",
    "chapter": 6,
    "chapterTitle": "چند روز ایک روڈ رولر کے ساتھ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "کرب",
    "meaning": "شدید تکلیف، اذیت",
    "chapter": 7,
    "chapterTitle": "منظور",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "نڈھال",
    "meaning": "تھکا ہوا، بے بس",
    "chapter": 7,
    "chapterTitle": "منظور",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "نقاہت",
    "meaning": "کمزوری",
    "chapter": 7,
    "chapterTitle": "منظور",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "داغِ مفارقت دینا",
    "meaning": "جدا ہو جانا، ساتھ چھوڑ جانا (عموماً موت کے باعث)",
    "chapter": 7,
    "chapterTitle": "منظور",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "افلاس زدہ",
    "meaning": "غربت کا مارا ہوا",
    "chapter": 7,
    "chapterTitle": "منظور",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "تمتمانا",
    "meaning": "چہرے کا سرخ اور روشن ہونا",
    "chapter": 7,
    "chapterTitle": "منظور",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "مفلوج",
    "meaning": "فالج زدہ، جسم کا کوئی حصہ حرکت کرنے کے قابل نہ رہنا",
    "chapter": 7,
    "chapterTitle": "منظور",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "نحیف",
    "meaning": "کمزور، لاغر",
    "chapter": 7,
    "chapterTitle": "منظور",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "کتبہ",
    "meaning": "نام یا عبارت کندہ پتھر، جو دروازے یا قبر پر لگایا جائے",
    "chapter": 8,
    "chapterTitle": "کتبہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "کہنہ فروش",
    "meaning": "پرانی چیزیں بیچنے والا",
    "chapter": 8,
    "chapterTitle": "کتبہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "کباڑی",
    "meaning": "ٹوٹی پھوٹی، پرانی چیزیں بیچنے والا دکاندار",
    "chapter": 8,
    "chapterTitle": "کتبہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "سعیِ لاحاصل",
    "meaning": "وہ کوشش جس کا کوئی نتیجہ نہ نکلے",
    "chapter": 8,
    "chapterTitle": "کتبہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "فارغ البالی",
    "meaning": "خوش حالی، بے فکری",
    "chapter": 8,
    "chapterTitle": "کتبہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "کفایت شعاری",
    "meaning": "ضرورت کے مطابق خرچ کرنا، بچت کرنا",
    "chapter": 8,
    "chapterTitle": "کتبہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "آلکس",
    "meaning": "سستی، کاہلی",
    "chapter": 8,
    "chapterTitle": "کتبہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "مژدہ",
    "meaning": "خوشخبری",
    "chapter": 8,
    "chapterTitle": "کتبہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "ٹونٹکار",
    "meaning": "جھگڑا، تکرار",
    "chapter": 9,
    "chapterTitle": "مائیں",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "آیۃ الکرسی",
    "meaning": "قرآن کی ایک مشہور آیت، جو مشکل وقت میں پڑھی جاتی ہے",
    "chapter": 9,
    "chapterTitle": "مائیں",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "مرگی",
    "meaning": "ایک اعصابی بیماری جس میں انسان کو دورے پڑتے ہیں",
    "chapter": 9,
    "chapterTitle": "مائیں",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "بہشتی",
    "meaning": "پانی بھر کر گھروں تک پہنچانے والا شخص",
    "chapter": 9,
    "chapterTitle": "مائیں",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "مشک",
    "meaning": "چمڑے کا وہ تھیلا جس میں پانی بھرا جاتا تھا",
    "chapter": 9,
    "chapterTitle": "مائیں",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "دم بخود",
    "meaning": "حیرت سے خاموش، بولنے کے قابل نہ رہنا",
    "chapter": 9,
    "chapterTitle": "مائیں",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "زناٹے سے",
    "meaning": "زور اور تیزی سے",
    "chapter": 9,
    "chapterTitle": "مائیں",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "وحشت زدہ",
    "meaning": "خوف زدہ، ڈرا ہوا",
    "chapter": 10,
    "chapterTitle": "سیاہ فام",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "امتدادِ زمانہ",
    "meaning": "وقت گزرنے کے ساتھ",
    "chapter": 10,
    "chapterTitle": "سیاہ فام",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "غنیم",
    "meaning": "دشمن",
    "chapter": 10,
    "chapterTitle": "سیاہ فام",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "اوسان خطا ہونا",
    "meaning": "ہوش و حواس کھو دینا",
    "chapter": 10,
    "chapterTitle": "سیاہ فام",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "دیدہ دلیری",
    "meaning": "بے خوفی، جرات",
    "chapter": 10,
    "chapterTitle": "سیاہ فام",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "سکتہ",
    "meaning": "بے حسی، حیرت سے ساکت ہو جانا",
    "chapter": 10,
    "chapterTitle": "سیاہ فام",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "بدر رو",
    "meaning": "گندے پانی کی نکاسی کا راستہ، نالی",
    "chapter": 10,
    "chapterTitle": "سیاہ فام",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "سنگسار کرنا",
    "meaning": "پتھر مار مار کر ہلاک کرنا",
    "chapter": 10,
    "chapterTitle": "سیاہ فام",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "ہکا بکا",
    "meaning": "حیران و پریشان",
    "chapter": 10,
    "chapterTitle": "سیاہ فام",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "آناً فاناً",
    "meaning": "پلک جھپکتے، فوراً",
    "chapter": 10,
    "chapterTitle": "سیاہ فام",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "کترانا",
    "meaning": "بچنے کی کوشش کرنا، دور ہو جانا",
    "chapter": 10,
    "chapterTitle": "سیاہ فام",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "مڈبھیڑ",
    "meaning": "آمنا سامنا، ملاقات",
    "chapter": 10,
    "chapterTitle": "سیاہ فام",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "مہاجر",
    "meaning": "ہجرت کر کے آنے والا شخص",
    "chapter": 11,
    "chapterTitle": "محسن محلہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "تنگی ترشی",
    "meaning": "مالی مشکل، غربت کی حالت",
    "chapter": 11,
    "chapterTitle": "محسن محلہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "بے پیچ",
    "meaning": "سادہ، بغیر کسی چالاکی کے",
    "chapter": 11,
    "chapterTitle": "محسن محلہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "مرنجان مرنج",
    "meaning": "نرم مزاج، کسی کو تکلیف نہ دینے والا",
    "chapter": 11,
    "chapterTitle": "محسن محلہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "سادہ لوح",
    "meaning": "بھولا، آسانی سے یقین کر لینے والا",
    "chapter": 11,
    "chapterTitle": "محسن محلہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "گھگھی بندھنا",
    "meaning": "شدید غم یا خوف سے آواز کا رک جانا",
    "chapter": 11,
    "chapterTitle": "محسن محلہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "رسمِ قل",
    "meaning": "میت کی وفات کے بعد قرآن خوانی کی رسم",
    "chapter": 11,
    "chapterTitle": "محسن محلہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "پہاڑے",
    "meaning": "ضربِ تقسیم کے جدول (2×1، 2×2 وغیرہ)",
    "chapter": 11,
    "chapterTitle": "محسن محلہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "مبالغہ آرائی",
    "meaning": "بات کو بڑھا چڑھا کر بیان کرنا",
    "chapter": 11,
    "chapterTitle": "محسن محلہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "شیخی بگھارنا",
    "meaning": "خود کو بڑا ظاہر کرنا، ڈینگ مارنا",
    "chapter": 11,
    "chapterTitle": "محسن محلہ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "نکھٹو",
    "meaning": "کاہل، کام چور",
    "chapter": 12,
    "chapterTitle": "کنڈکٹر",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "تتلاہٹ",
    "meaning": "الفاظ صحیح طور پر ادا نہ کر پانے کی کیفیت",
    "chapter": 12,
    "chapterTitle": "کنڈکٹر",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "آبدیدہ",
    "meaning": "آنسوؤں سے بھری آنکھیں، رونے کے قریب",
    "chapter": 12,
    "chapterTitle": "کنڈکٹر",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "خناس",
    "meaning": "غلط یا سرکش خیال",
    "chapter": 12,
    "chapterTitle": "کنڈکٹر",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "طمانیت",
    "meaning": "اطمینان، سکون",
    "chapter": 12,
    "chapterTitle": "کنڈکٹر",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "فق ہونا",
    "meaning": "خوف یا صدمے سے رنگ اڑ جانا",
    "chapter": 12,
    "chapterTitle": "کنڈکٹر",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "نذرانۂ عقیدت",
    "meaning": "محبت و عقیدت کے طور پر پیش کی گئی چیز",
    "chapter": 12,
    "chapterTitle": "کنڈکٹر",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "ناتراشیدہ",
    "meaning": "بغیر تراشا ہوا، خام حالت میں",
    "chapter": 13,
    "chapterTitle": "ایک وصیت کی تعمیل",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "رکاکت",
    "meaning": "پھسپھسا پن، سطحی یا نیچے درجے کی بات",
    "chapter": 13,
    "chapterTitle": "ایک وصیت کی تعمیل",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "زود فہمی",
    "meaning": "جلدی سمجھ جانے کی صلاحیت",
    "chapter": 13,
    "chapterTitle": "ایک وصیت کی تعمیل",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "طبع رسا",
    "meaning": "تیز اور گہری سمجھ بوجھ",
    "chapter": 13,
    "chapterTitle": "ایک وصیت کی تعمیل",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "خنک سالی",
    "meaning": "مشکل یا کمی کا زمانہ",
    "chapter": 13,
    "chapterTitle": "ایک وصیت کی تعمیل",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "ملکہ",
    "meaning": "مہارت، خاص صلاحیت",
    "chapter": 13,
    "chapterTitle": "ایک وصیت کی تعمیل",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "حاشیۂ خیال",
    "meaning": "سوچ کی حد، خیال میں آنا",
    "chapter": 13,
    "chapterTitle": "ایک وصیت کی تعمیل",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "اربابِ حل و عقد",
    "meaning": "معاملات کا فیصلہ کرنے والے ذمہ دار افراد",
    "chapter": 13,
    "chapterTitle": "ایک وصیت کی تعمیل",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "باریاب ہونا",
    "meaning": "کسی بڑی شخصیت سے ملاقات کا شرف حاصل کرنا",
    "chapter": 14,
    "chapterTitle": "علامہ اقبالؒ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "استعجاب",
    "meaning": "حیرت",
    "chapter": 14,
    "chapterTitle": "علامہ اقبالؒ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "تصنع",
    "meaning": "بناوٹ، دکھاوا",
    "chapter": 14,
    "chapterTitle": "علامہ اقبالؒ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "انکسار",
    "meaning": "عاجزی، فروتنی",
    "chapter": 14,
    "chapterTitle": "علامہ اقبالؒ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "پرنم",
    "meaning": "آنسوؤں سے بھری ہوئی (آنکھیں)",
    "chapter": 14,
    "chapterTitle": "علامہ اقبالؒ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "حسن و قبح",
    "meaning": "اچھائی اور برائی",
    "chapter": 14,
    "chapterTitle": "علامہ اقبالؒ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "دل آویز",
    "meaning": "دل کو موہ لینے والی",
    "chapter": 14,
    "chapterTitle": "علامہ اقبالؒ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "حاجب",
    "meaning": "دربان، وہ شخص جو ملاقات سے پہلے روکے",
    "chapter": 14,
    "chapterTitle": "علامہ اقبالؒ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "مزاج پرسی",
    "meaning": "خیریت پوچھنا",
    "chapter": 14,
    "chapterTitle": "علامہ اقبالؒ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "اہلِ محفل",
    "meaning": "محفل میں موجود لوگ",
    "chapter": 14,
    "chapterTitle": "علامہ اقبالؒ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "سامعین",
    "meaning": "سننے والے",
    "chapter": 14,
    "chapterTitle": "علامہ اقبالؒ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "مشتِ استخواں",
    "meaning": "ہڈیوں کا ڈھانچہ، انتہائی دبلا پتلا",
    "chapter": 14,
    "chapterTitle": "علامہ اقبالؒ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "دھان پان",
    "meaning": "لاغر، کمزور جسم والا",
    "chapter": 14,
    "chapterTitle": "علامہ اقبالؒ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "متانت",
    "meaning": "سنجیدگی، وقار",
    "chapter": 14,
    "chapterTitle": "علامہ اقبالؒ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "عرق عرق ہونا",
    "meaning": "پسینے سے شرابور ہو جانا",
    "chapter": 14,
    "chapterTitle": "علامہ اقبالؒ",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "سجادہ نشین",
    "meaning": "کسی صوفی بزرگ کی گدی یا خانقاہ کا جانشین",
    "chapter": 15,
    "chapterTitle": "طائرِ لاہوتی",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "وسیع المشرب",
    "meaning": "کھلے ذہن کا، روادار",
    "chapter": 15,
    "chapterTitle": "طائرِ لاہوتی",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "مجذوب",
    "meaning": "دنیا سے بے نیاز، اللہ کی محبت میں گم رہنے والا",
    "chapter": 15,
    "chapterTitle": "طائرِ لاہوتی",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "مراقبہ",
    "meaning": "گہری روحانی سوچ میں ڈوب جانا",
    "chapter": 15,
    "chapterTitle": "طائرِ لاہوتی",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "ضرب المثل",
    "meaning": "مشہور مثال بن جانا",
    "chapter": 15,
    "chapterTitle": "طائرِ لاہوتی",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "فروگذاشت",
    "meaning": "کوتاہی، غفلت",
    "chapter": 15,
    "chapterTitle": "طائرِ لاہوتی",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "رہینِ منت",
    "meaning": "کسی کا احسان مند، مرہونِ منت",
    "chapter": 15,
    "chapterTitle": "طائرِ لاہوتی",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "گل افشانیِ تقریر",
    "meaning": "خوبصورت اور دلکش انداز میں گفتگو کرنا",
    "chapter": 15,
    "chapterTitle": "طائرِ لاہوتی",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "زمہریر",
    "meaning": "سخت سردی",
    "chapter": 15,
    "chapterTitle": "طائرِ لاہوتی",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "سالارِ کارواں",
    "meaning": "قافلے کا سردار، رہنما",
    "chapter": 15,
    "chapterTitle": "طائرِ لاہوتی",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "مسندِ ارشاد",
    "meaning": "روحانی رہنمائی کا اعلیٰ مقام",
    "chapter": 15,
    "chapterTitle": "طائرِ لاہوتی",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "تسکینِ نخوت",
    "meaning": "غرور کی تسلی، انا کی خوشنودی",
    "chapter": 16,
    "chapterTitle": "مریدپور کا پیر",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "ببانگِ دہل",
    "meaning": "کھلے عام، زور سے اعلان کرتے ہوئے",
    "chapter": 16,
    "chapterTitle": "مریدپور کا پیر",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "مدبّر",
    "meaning": "دانا، تدبیر کرنے والا",
    "chapter": 16,
    "chapterTitle": "مریدپور کا پیر",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "معرکہ الآرا",
    "meaning": "زبردست، دھوم مچا دینے والا",
    "chapter": 16,
    "chapterTitle": "مریدپور کا پیر",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "نامعقول",
    "meaning": "بے عقل، غیر مناسب",
    "chapter": 16,
    "chapterTitle": "مریدپور کا پیر",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "زقند بھرنا",
    "meaning": "تیزی سے چھلانگ لگانا",
    "chapter": 16,
    "chapterTitle": "مریدپور کا پیر",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "خفیف",
    "meaning": "ہلکی سی، معمولی",
    "chapter": 16,
    "chapterTitle": "مریدپور کا پیر",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "رعشہ",
    "meaning": "کپکپاہٹ، لرزنا",
    "chapter": 16,
    "chapterTitle": "مریدپور کا پیر",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "براہینِ قاطع",
    "meaning": "ناقابلِ تردید دلائل",
    "chapter": 16,
    "chapterTitle": "مریدپور کا پیر",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "شغلِ بیکاری",
    "meaning": "فارغ وقت کا مشغلہ",
    "chapter": 16,
    "chapterTitle": "مریدپور کا پیر",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "انشا پردازی",
    "meaning": "عمدہ اور خوبصورت تحریر لکھنے کا فن",
    "chapter": 16,
    "chapterTitle": "مریدپور کا پیر",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "صحیح الدماغی",
    "meaning": "دماغی طور پر درست اور سمجھدار ہونا",
    "chapter": 16,
    "chapterTitle": "مریدپور کا پیر",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "چار دانگ عالم",
    "meaning": "پوری دنیا، ہر طرف",
    "chapter": 16,
    "chapterTitle": "مریدپور کا پیر",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "منحنی",
    "meaning": "کمزور، دبی ہوئی",
    "chapter": 16,
    "chapterTitle": "مریدپور کا پیر",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "بھنّا جانا",
    "meaning": "غصے سے بے قابو ہو جانا",
    "chapter": 16,
    "chapterTitle": "مریدپور کا پیر",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "حاضرین",
    "meaning": "موجود لوگ، سامعین",
    "chapter": 16,
    "chapterTitle": "مریدپور کا پیر",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "آڑھتی",
    "meaning": "تھوک کا سوداگر، بیوپاری",
    "chapter": 17,
    "chapterTitle": "حاجی اورنگ زیب خان",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "استغراق",
    "meaning": "مکمل توجہ، ڈوب جانا",
    "chapter": 17,
    "chapterTitle": "حاجی اورنگ زیب خان",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "برہانِ قاطع",
    "meaning": "ناقابلِ تردید دلیل",
    "chapter": 17,
    "chapterTitle": "حاجی اورنگ زیب خان",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "اہالی موالی",
    "meaning": "ساتھی، رشتہ دار اور حامی",
    "chapter": 17,
    "chapterTitle": "حاجی اورنگ زیب خان",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "شیوہ",
    "meaning": "عادت، طریقہ",
    "chapter": 17,
    "chapterTitle": "حاجی اورنگ زیب خان",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "حلیف",
    "meaning": "ساتھی، اتحادی",
    "chapter": 17,
    "chapterTitle": "حاجی اورنگ زیب خان",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "تردّد",
    "meaning": "پریشانی، فکرمندی",
    "chapter": 17,
    "chapterTitle": "حاجی اورنگ زیب خان",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "دوزانو",
    "meaning": "گھٹنوں کے بل بیٹھنا",
    "chapter": 17,
    "chapterTitle": "حاجی اورنگ زیب خان",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "قضیہ",
    "meaning": "جھگڑا، تنازعہ",
    "chapter": 17,
    "chapterTitle": "حاجی اورنگ زیب خان",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "دیدۂ عبرت نگاہ",
    "meaning": "عبرت سے دیکھنے والی نظر، یہاں مراد اپنی حالت پر ترس دلانا",
    "chapter": 17,
    "chapterTitle": "حاجی اورنگ زیب خان",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "مفلوک الحالی",
    "meaning": "غریبی، بری حالت",
    "chapter": 17,
    "chapterTitle": "حاجی اورنگ زیب خان",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "کماد کے کھیت میں کبڈی",
    "meaning": "مشکل اور خطرناک کام، جہاں دھوکا آسان ہو",
    "chapter": 17,
    "chapterTitle": "حاجی اورنگ زیب خان",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "خوگ ژوند",
    "meaning": "پشتو محاورہ، میٹھی اور خوش حال زندگی",
    "chapter": 17,
    "chapterTitle": "حاجی اورنگ زیب خان",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "حساب دوستاں در دل",
    "meaning": "دوستوں کا حساب دل میں رکھا جاتا ہے، لکھا نہیں جاتا",
    "chapter": 17,
    "chapterTitle": "حاجی اورنگ زیب خان",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "شائستۂ حیات",
    "meaning": "زندگی کا تجربہ کار اور باشعور انسان",
    "chapter": 17,
    "chapterTitle": "حاجی اورنگ زیب خان",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "اتمامِ حجت",
    "meaning": "دلیل سے بات مکمل کر کے قائل کرنا",
    "chapter": 17,
    "chapterTitle": "حاجی اورنگ زیب خان",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "مدارات",
    "meaning": "خاطر تواضع، مہمان نوازی",
    "chapter": 17,
    "chapterTitle": "حاجی اورنگ زیب خان",
    "poet": "",
    "type": "نثر",
    "source": "chapter"
  },
  {
    "word": "قدسی الاصل",
    "meaning": "پاکیزہ اصل رکھنے والی",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "رفعت",
    "meaning": "بلندی",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "گردوں",
    "meaning": "آسمان",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "فتنہ گر",
    "meaning": "فساد پیدا کرنے والا",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "نالۂ بیباک",
    "meaning": "بے خوف فریاد",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "پیرِ گردوں",
    "meaning": "آسمان کا بزرگ، کنایۃً زحل (سیارہ)",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "عرشِ بریں",
    "meaning": "اللہ کا بلند ترین تخت",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "کہکشاں",
    "meaning": "آکاش گنگا",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "رضواں",
    "meaning": "جنت کے دربان فرشتے کا نام",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "تگ و تاز",
    "meaning": "دوڑ دھوپ، کوشش",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "سُکّانِ زمیں",
    "meaning": "زمین پر رہنے والے",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "شوخ و گستاخ",
    "meaning": "بے باک اور بے ادب",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "پستی کے مکیں",
    "meaning": "نیچی جگہ یعنی زمین پر رہنے والے",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "مسجودِ ملائک",
    "meaning": "جسے فرشتوں نے سجدہ کیا",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "عالمِ کیف",
    "meaning": "حالت اور کیفیت کا جاننے والا",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "دانائے رموزِ کم",
    "meaning": "مقدار اور اسباب کے راز جاننے والا",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "عجز",
    "meaning": "عاجزی، انکساری",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "نا محرم",
    "meaning": "ناواقف",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "غم انگیز",
    "meaning": "دکھ سے بھرا ہوا",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "اشکِ بیتاب",
    "meaning": "بےقرار آنسو",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "نعرۂ مستانہ",
    "meaning": "مستی اور جوش سے بھری آواز",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "حُسنِ ادا",
    "meaning": "خوبصورت انداز",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "ہم سخن",
    "meaning": "ہمکلام، بات کرنے والا",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "مائل بہ کرم",
    "meaning": "مہربانی کرنے کو تیار",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "سائل",
    "meaning": "مانگنے والا",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "رہروِ منزل",
    "meaning": "منزل کی طرف چلنے والا مسافر",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "جوہرِ قابل",
    "meaning": "قابلیت کی صلاحیت",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "گِل",
    "meaning": "مٹی",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "الحاد",
    "meaning": "بےدینی، کفر",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "بت شکن",
    "meaning": "بت توڑنے والا",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "بت گر",
    "meaning": "بت بنانے والا",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "پدر",
    "meaning": "باپ",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "بادہ آشام",
    "meaning": "شراب پینے والا",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "خُم",
    "meaning": "شراب کا مٹکا",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "صفحۂ دہر",
    "meaning": "زمانے کا صفحہ، تاریخ",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "باطل",
    "meaning": "جھوٹ، ناحق",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "جبیناں",
    "meaning": "پیشانیاں (سجدہ کرنے والی)",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "آبا",
    "meaning": "آباؤ اجداد",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "منتظرِ فردا",
    "meaning": "آنے والے کل کا انتظار کرنے والا",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "فاطرِ ہستی",
    "meaning": "کائنات کو پیدا کرنے والا، اللہ",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "قصور",
    "meaning": "محلات (جنت کے)",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "جلوۂ طور",
    "meaning": "کوہِ طور پر اللہ کی تجلی کا ظہور",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "یورشِ تاتار",
    "meaning": "تاتاریوں کا حملہ",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "پاسباں",
    "meaning": "محافظ",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "صنم خانہ",
    "meaning": "بت خانہ",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "عصرِ نو",
    "meaning": "نیا زمانہ",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "بو",
    "meaning": "خوشبو",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "غنچہ",
    "meaning": "کلی",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "رختِ بردوش",
    "meaning": "سامان کندھے پر اٹھائے ہوئے",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "تنک مایہ",
    "meaning": "کم حیثیت، معمولی",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "بیاباں",
    "meaning": "صحرا",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "دہر",
    "meaning": "دنیا، زمانہ",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "ذوقِ تن آسانی",
    "meaning": "آرام طلبی کا شوق",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "حیدریؓ فقر",
    "meaning": "حضرت علیؓ جیسی سادگی اور درویشی",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "نسبتِ روحانی",
    "meaning": "روحانی تعلق",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "اسلاف",
    "meaning": "بزرگ، پہلے گزرے ہوئے لوگ",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "تارکِ قرآں",
    "meaning": "قرآن کو چھوڑنے والا",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "سپر",
    "meaning": "ڈھال",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "شمشیر",
    "meaning": "تلوار",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "جہانگیر",
    "meaning": "دنیا کو فتح کرنے والی",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "ماسوائے اللہ",
    "meaning": "اللہ کے سوا ہر چیز",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "لوح و قلم",
    "meaning": "تختی اور قلم، یعنی تقدیر لکھنے کا نظام",
    "chapter": 18,
    "chapterTitle": "جواب شکوہ",
    "poet": "علامہ محمد اقبالؒ",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "دشت و ریگزار",
    "meaning": "صحرا اور ریتیلا میدان",
    "chapter": 19,
    "chapterTitle": "بڑھے چلو",
    "poet": "اختر شیرانی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "سیل و جوئے بار",
    "meaning": "سیلاب اور بہتی ندیاں",
    "chapter": 19,
    "chapterTitle": "بڑھے چلو",
    "poet": "اختر شیرانی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "بحر و کوہسار",
    "meaning": "سمندر اور پہاڑ",
    "chapter": 19,
    "chapterTitle": "بڑھے چلو",
    "poet": "اختر شیرانی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "کٹھن",
    "meaning": "مشکل",
    "chapter": 19,
    "chapterTitle": "بڑھے چلو",
    "poet": "اختر شیرانی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "دلاورانِ تیغ زن",
    "meaning": "تلوار چلانے والے بہادر",
    "chapter": 19,
    "chapterTitle": "بڑھے چلو",
    "poet": "اختر شیرانی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "بہادرانِ صف شکن",
    "meaning": "دشمن کی صفیں توڑنے والے بہادر",
    "chapter": 19,
    "chapterTitle": "بڑھے چلو",
    "poet": "اختر شیرانی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "تیغِ تیز",
    "meaning": "تیز دھار تلوار",
    "chapter": 19,
    "chapterTitle": "بڑھے چلو",
    "poet": "اختر شیرانی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "افتخار",
    "meaning": "فخر",
    "chapter": 19,
    "chapterTitle": "بڑھے چلو",
    "poet": "اختر شیرانی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "مرگ و زیست",
    "meaning": "موت اور زندگی",
    "chapter": 19,
    "chapterTitle": "بڑھے چلو",
    "poet": "اختر شیرانی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "انحصار",
    "meaning": "بھروسا، دارومدار",
    "chapter": 19,
    "chapterTitle": "بڑھے چلو",
    "poet": "اختر شیرانی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "عشقِ بے قرار",
    "meaning": "بےچین کر دینے والی محبت",
    "chapter": 19,
    "chapterTitle": "بڑھے چلو",
    "poet": "اختر شیرانی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "لگن",
    "meaning": "شوق، جستجو",
    "chapter": 19,
    "chapterTitle": "بڑھے چلو",
    "poet": "اختر شیرانی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "تیغِ بے اماں",
    "meaning": "بےرحم تلوار جو کسی کو معاف نہ کرے",
    "chapter": 19,
    "chapterTitle": "بڑھے چلو",
    "poet": "اختر شیرانی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "عمرِ نوجواں",
    "meaning": "جوانی کی زندگی",
    "chapter": 19,
    "chapterTitle": "بڑھے چلو",
    "poet": "اختر شیرانی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "نثار کرنا",
    "meaning": "قربان کرنا",
    "chapter": 19,
    "chapterTitle": "بڑھے چلو",
    "poet": "اختر شیرانی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "صدا دینا",
    "meaning": "پکارنا",
    "chapter": 19,
    "chapterTitle": "بڑھے چلو",
    "poet": "اختر شیرانی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "قسمتِ سعید",
    "meaning": "خوش نصیبی، اچھی تقدیر",
    "chapter": 19,
    "chapterTitle": "بڑھے چلو",
    "poet": "اختر شیرانی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "رزم گہ",
    "meaning": "میدانِ جنگ",
    "chapter": 19,
    "chapterTitle": "بڑھے چلو",
    "poet": "اختر شیرانی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "سپاہیانہ عید",
    "meaning": "سپاہی کے لیے خوشی کا موقع",
    "chapter": 19,
    "chapterTitle": "بڑھے چلو",
    "poet": "اختر شیرانی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "فخرِ قوم",
    "meaning": "قوم کا وقار اور عزت",
    "chapter": 19,
    "chapterTitle": "بڑھے چلو",
    "poet": "اختر شیرانی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "سروں سے کفن باندھنا",
    "meaning": "موت کے لیے پہلے سے تیار ہو جانا (محاورہ)",
    "chapter": 19,
    "chapterTitle": "بڑھے چلو",
    "poet": "اختر شیرانی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "روح فزا",
    "meaning": "روح کو تازگی دینے والا",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "رخسارِ سحر",
    "meaning": "صبح کا چہرہ",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "دلِ زار",
    "meaning": "غمگین دل",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "فردوسِ نظر",
    "meaning": "آنکھوں کے لیے جنت",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "عرقِ حسن",
    "meaning": "خوبصورتی کی چمک، تازگی",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "ذرّۂ ناچیز",
    "meaning": "حقیر سا ذرہ",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "طور کا شعلہ",
    "meaning": "کوہِ طور پر ظاہر ہونے والا الٰہی نور",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "لرزش",
    "meaning": "کپکپاہٹ، تھرتھراہٹ",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "تبسم",
    "meaning": "مسکراہٹ",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "ترنم",
    "meaning": "خوش الحانی، میٹھا سُر",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "تصادم",
    "meaning": "ٹکراؤ",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "تلاطم",
    "meaning": "ہلچل، طغیانی",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "نسیمِ سحری",
    "meaning": "صبح کی ہوا",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "گیسو",
    "meaning": "بال",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "چٹکنا",
    "meaning": "کِھلنا",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "مدھم",
    "meaning": "ہلکی، دھیمی",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "گلِ تر",
    "meaning": "تازہ پھول",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "لہکنا",
    "meaning": "لہرانا، جھومنا",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "خنکی",
    "meaning": "ٹھنڈک",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "بیاباں",
    "meaning": "جنگل، صحرا",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "مصفا",
    "meaning": "صاف شفاف",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "پیشانیِ گردوں",
    "meaning": "آسمان کی پیشانی",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "انبار",
    "meaning": "ڈھیر",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "انوارِ خدا",
    "meaning": "اللہ کی روشنیاں",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "صبحِ صادق",
    "meaning": "حقیقی صبح، طلوعِ فجر کا وقت",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "زریں",
    "meaning": "سنہری",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "لبریز",
    "meaning": "بھرا ہوا",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "پیراہنِ یوسفؑ",
    "meaning": "حضرت یوسفؑ کا کرتہ",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "برگِ گل",
    "meaning": "پھول کی پتی",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "لطافت",
    "meaning": "نزاکت، نرمی",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "جلوۂ اصنام",
    "meaning": "بتوں کی رونق",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "زاہد",
    "meaning": "عبادت گزار",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "صباحت",
    "meaning": "خوبصورتی",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "ناقوس",
    "meaning": "مندر یا گرجے میں بجایا جانے والا گھنٹہ",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "قربِ ہنگام",
    "meaning": "قربت کا وقت",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "سرشار",
    "meaning": "مست، خوشی سے بھرپور",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "آلام",
    "meaning": "دکھ، تکلیفیں",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "خودی",
    "meaning": "انا، نفس",
    "chapter": 20,
    "chapterTitle": "مناظرِ سحر",
    "poet": "جوش ملیح آبادی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "امنگ",
    "meaning": "خواہش، آرزو",
    "chapter": 21,
    "chapterTitle": "شکست کی آواز",
    "poet": "میرا جی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "فلک",
    "meaning": "آسمان",
    "chapter": 21,
    "chapterTitle": "شکست کی آواز",
    "poet": "میرا جی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "ماہ پارے",
    "meaning": "چاند کے ٹکڑے، حسین و نایاب چیزیں",
    "chapter": 21,
    "chapterTitle": "شکست کی آواز",
    "poet": "میرا جی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "شعوری",
    "meaning": "ہوش و آگہی سے متعلق، دانستہ",
    "chapter": 21,
    "chapterTitle": "شکست کی آواز",
    "poet": "میرا جی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "جہانِ نَو",
    "meaning": "نئی دنیا",
    "chapter": 21,
    "chapterTitle": "شکست کی آواز",
    "poet": "میرا جی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "قلبِ سمندر",
    "meaning": "سمندر کا دل، یعنی گہرائی",
    "chapter": 21,
    "chapterTitle": "شکست کی آواز",
    "poet": "میرا جی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "بیاباں",
    "meaning": "ویرانہ، جنگل",
    "chapter": 21,
    "chapterTitle": "شکست کی آواز",
    "poet": "میرا جی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "منجمد",
    "meaning": "جما ہوا، ٹھوس",
    "chapter": 21,
    "chapterTitle": "شکست کی آواز",
    "poet": "میرا جی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "لا انتہا",
    "meaning": "جس کی کوئی انتہا نہ ہو",
    "chapter": 21,
    "chapterTitle": "شکست کی آواز",
    "poet": "میرا جی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "کثرت سے",
    "meaning": "زیادہ تعداد میں",
    "chapter": 21,
    "chapterTitle": "شکست کی آواز",
    "poet": "میرا جی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "محدود",
    "meaning": "جس کی کوئی حد ہو، غیر لامحدود",
    "chapter": 21,
    "chapterTitle": "شکست کی آواز",
    "poet": "میرا جی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "تمدن",
    "meaning": "تہذیب، معاشرتی نظام",
    "chapter": 21,
    "chapterTitle": "شکست کی آواز",
    "poet": "میرا جی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "پھندا",
    "meaning": "جال، قید",
    "chapter": 21,
    "chapterTitle": "شکست کی آواز",
    "poet": "میرا جی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "مشیت",
    "meaning": "اللہ کی مرضی، تقدیر",
    "chapter": 21,
    "chapterTitle": "شکست کی آواز",
    "poet": "میرا جی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "تسکین",
    "meaning": "سکون، اطمینان",
    "chapter": 21,
    "chapterTitle": "شکست کی آواز",
    "poet": "میرا جی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "لکیر کا فقیر",
    "meaning": "پرانے رواج پر بغیر سوچے عمل کرنے والا",
    "chapter": 21,
    "chapterTitle": "شکست کی آواز",
    "poet": "میرا جی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "ضعیفی",
    "meaning": "کمزوری، بڑھاپا",
    "chapter": 21,
    "chapterTitle": "شکست کی آواز",
    "poet": "میرا جی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "پیری",
    "meaning": "بڑھاپا",
    "chapter": 21,
    "chapterTitle": "شکست کی آواز",
    "poet": "میرا جی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "جذبِ ساکن",
    "meaning": "رکی ہوئی، غیر متحرک کشش",
    "chapter": 21,
    "chapterTitle": "شکست کی آواز",
    "poet": "میرا جی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "جوالا",
    "meaning": "آگ کا شعلہ، سلگتی ہوئی خواہش",
    "chapter": 21,
    "chapterTitle": "شکست کی آواز",
    "poet": "میرا جی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "ہستی",
    "meaning": "وجود",
    "chapter": 21,
    "chapterTitle": "شکست کی آواز",
    "poet": "میرا جی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "جوئے نغمہ",
    "meaning": "نغمے کی ندی، گیتوں کا دھارا",
    "chapter": 22,
    "chapterTitle": "ستارے",
    "poet": "ن۔م۔راشد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "خُلد زارِ ماہ و انجم",
    "meaning": "چاند ستاروں کا آسمانی باغِ بہشت",
    "chapter": 22,
    "chapterTitle": "ستارے",
    "poet": "ن۔م۔راشد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "نوحہ آبادِ جہاں",
    "meaning": "دنیا کی غم زدہ بستی",
    "chapter": 22,
    "chapterTitle": "ستارے",
    "poet": "ن۔م۔راشد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "گلستانِ ترنّم",
    "meaning": "نغمے کا باغ",
    "chapter": 22,
    "chapterTitle": "ستارے",
    "poet": "ن۔م۔راشد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "مدبھرا",
    "meaning": "نشہ آور، سرور انگیز",
    "chapter": 22,
    "chapterTitle": "ستارے",
    "poet": "ن۔م۔راشد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "تبسم",
    "meaning": "مسکراہٹ",
    "chapter": 22,
    "chapterTitle": "ستارے",
    "poet": "ن۔م۔راشد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "دیارِ زندگی",
    "meaning": "زندگی کی بستی",
    "chapter": 22,
    "chapterTitle": "ستارے",
    "poet": "ن۔م۔راشد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "تکلّم",
    "meaning": "گفتگو، بات چیت",
    "chapter": 22,
    "chapterTitle": "ستارے",
    "poet": "ن۔م۔راشد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "روزِ اوّلیں",
    "meaning": "پہلا دن، ازل سے",
    "chapter": 22,
    "chapterTitle": "ستارے",
    "poet": "ن۔م۔راشد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "مسرّت",
    "meaning": "خوشی",
    "chapter": 22,
    "chapterTitle": "ستارے",
    "poet": "ن۔م۔راشد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "فکرِ ہستی",
    "meaning": "زندگی کی فکر و پریشانی",
    "chapter": 22,
    "chapterTitle": "ستارے",
    "poet": "ن۔م۔راشد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "نور پارے",
    "meaning": "روشنی کے ٹکڑے، ستارے",
    "chapter": 22,
    "chapterTitle": "ستارے",
    "poet": "ن۔م۔راشد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "خاک داں",
    "meaning": "زمین، دنیا",
    "chapter": 22,
    "chapterTitle": "ستارے",
    "poet": "ن۔م۔راشد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "گہوارۂ حسن و لطافت",
    "meaning": "خوبصورتی اور نزاکت کا جھولا",
    "chapter": 22,
    "chapterTitle": "ستارے",
    "poet": "ن۔م۔راشد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "گم شدہ جنّت",
    "meaning": "کھویا ہوا جنت",
    "chapter": 22,
    "chapterTitle": "ستارے",
    "poet": "ن۔م۔راشد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "شومیِ تقدیر",
    "meaning": "بری قسمت، بدنصیبی",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "ماتمِ ناکامی",
    "meaning": "ناکامی کا سوگ منانا",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "شیون",
    "meaning": "رونا، نوحہ",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "جورِ فلک",
    "meaning": "آسمان یعنی زمانے کا ظلم",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "فلکِ پیر",
    "meaning": "پرانا آسمان، پرانا زمانہ",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "بے مہریِ ایام",
    "meaning": "زمانے کی بے رحمی",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "چمنستان",
    "meaning": "باغ، گلستان",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "محرومِ تجلّی",
    "meaning": "روشنی سے محروم",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "شبستان",
    "meaning": "خوابگاہ",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "دبستان",
    "meaning": "علم کا مرکز، مکتب",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "نالہ و شیون",
    "meaning": "رونا پیٹنا",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "چارۂ درد",
    "meaning": "درد کا علاج",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "اُجڑی",
    "meaning": "ویران، تباہ",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "جکڑی ہوئی",
    "meaning": "قید کی ہوئی، بندھی ہوئی",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "پیروی",
    "meaning": "تقلید کرنا، پیچھے چلنا",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "مسلکِ فرہاد",
    "meaning": "فرہاد کا طریقہ (محنت و استقلال کی علامت)",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "شرطِ وفا",
    "meaning": "وفاداری کا تقاضا",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "ہنگامہ",
    "meaning": "شور، فساد",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "برپا",
    "meaning": "قائم، جاری",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "خوں کا پیاسا",
    "meaning": "جانی دشمن، قتل کا خواہش مند",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "جنسِ گراں مایہ",
    "meaning": "قیمتی چیز (یہاں وفا مراد ہے)",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "جامِ جم",
    "meaning": "بادشاہ جمشید کا جام، شان و شوکت کی علامت",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "شوکتِ کے",
    "meaning": "کیانی بادشاہوں کی شان و شوکت",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "حشمتِ روم",
    "meaning": "روم کی عظمت و شان",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "صولتِ رے",
    "meaning": "رے شہر کا دبدبہ",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "خدشۂ آلام",
    "meaning": "رنج و غم کا اندیشہ",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "مکر و ریا",
    "meaning": "فریب اور دکھاوا",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "کاسۂ حرص و ہوا",
    "meaning": "لالچ اور خواہش کا پیالہ",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "طرزِ ادا",
    "meaning": "انداز، طریقہ",
    "chapter": 23,
    "chapterTitle": "نفیرِ عمل",
    "poet": "مجید امجد",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "ڈھارس بندھانا",
    "meaning": "حوصلہ دینا، تسلی دینا",
    "chapter": 24,
    "chapterTitle": "ہمیشہ دیر کر دیتا ہوں",
    "poet": "منیر نیازی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "دیرینہ",
    "meaning": "پرانا",
    "chapter": 24,
    "chapterTitle": "ہمیشہ دیر کر دیتا ہوں",
    "poet": "منیر نیازی",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "مامتا",
    "meaning": "ماں جیسی محبت و شفقت",
    "chapter": 25,
    "chapterTitle": "بڑے ڈرپوک ہو تارو!",
    "poet": "وزیر آغا",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "اوڑھنی",
    "meaning": "چادر، دوپٹہ",
    "chapter": 25,
    "chapterTitle": "بڑے ڈرپوک ہو تارو!",
    "poet": "وزیر آغا",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "تیرگی",
    "meaning": "اندھیرا",
    "chapter": 25,
    "chapterTitle": "بڑے ڈرپوک ہو تارو!",
    "poet": "وزیر آغا",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "پیوست",
    "meaning": "گڑا ہوا، جڑا ہوا",
    "chapter": 25,
    "chapterTitle": "بڑے ڈرپوک ہو تارو!",
    "poet": "وزیر آغا",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "منور",
    "meaning": "روشن، جگمگاتا ہوا",
    "chapter": 25,
    "chapterTitle": "بڑے ڈرپوک ہو تارو!",
    "poet": "وزیر آغا",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "بے انت",
    "meaning": "لامحدود، بے پایاں",
    "chapter": 25,
    "chapterTitle": "بڑے ڈرپوک ہو تارو!",
    "poet": "وزیر آغا",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "برچھیاں",
    "meaning": "نیزے",
    "chapter": 25,
    "chapterTitle": "بڑے ڈرپوک ہو تارو!",
    "poet": "وزیر آغا",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "گرز",
    "meaning": "بھاری ہتھیار، گدا",
    "chapter": 25,
    "chapterTitle": "بڑے ڈرپوک ہو تارو!",
    "poet": "وزیر آغا",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "سُورما",
    "meaning": "بہادر جنگجو",
    "chapter": 25,
    "chapterTitle": "بڑے ڈرپوک ہو تارو!",
    "poet": "وزیر آغا",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "اُفق کی قوس",
    "meaning": "آسمان کا خمیدہ کنارہ، طلوع و غروب کی جگہ",
    "chapter": 25,
    "chapterTitle": "بڑے ڈرپوک ہو تارو!",
    "poet": "وزیر آغا",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "کہرام",
    "meaning": "شور و غل، ہنگامہ",
    "chapter": 25,
    "chapterTitle": "بڑے ڈرپوک ہو تارو!",
    "poet": "وزیر آغا",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "بے خطر",
    "meaning": "بغیر ڈر کے",
    "chapter": 25,
    "chapterTitle": "بڑے ڈرپوک ہو تارو!",
    "poet": "وزیر آغا",
    "type": "نظم",
    "source": "chapter"
  },
  {
    "word": "ظلمت خانۂ دل",
    "meaning": "دل کا تاریک گھر",
    "chapter": 26,
    "chapterTitle": "جنہیں میں ڈھونڈتا تھا آسمانوں میں زمینوں میں",
    "poet": "علامہ اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "مکین",
    "meaning": "رہنے والا، باسی",
    "chapter": 26,
    "chapterTitle": "جنہیں میں ڈھونڈتا تھا آسمانوں میں زمینوں میں",
    "poet": "علامہ اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "محمل نشین",
    "meaning": "کجاوے میں بیٹھنے والا",
    "chapter": 26,
    "chapterTitle": "جنہیں میں ڈھونڈتا تھا آسمانوں میں زمینوں میں",
    "poet": "علامہ اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "وصل",
    "meaning": "ملاپ، محبوب سے ملنا",
    "chapter": 26,
    "chapterTitle": "جنہیں میں ڈھونڈتا تھا آسمانوں میں زمینوں میں",
    "poet": "علامہ اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "ناخدا",
    "meaning": "کشتی بان، ملاح",
    "chapter": 26,
    "chapterTitle": "جنہیں میں ڈھونڈتا تھا آسمانوں میں زمینوں میں",
    "poet": "علامہ اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "سفینہ",
    "meaning": "کشتی، جہاز",
    "chapter": 26,
    "chapterTitle": "جنہیں میں ڈھونڈتا تھا آسمانوں میں زمینوں میں",
    "poet": "علامہ اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "شمعِ کشتہ",
    "meaning": "بجھی ہوئی شمع",
    "chapter": 26,
    "chapterTitle": "جنہیں میں ڈھونڈتا تھا آسمانوں میں زمینوں میں",
    "poet": "علامہ اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "موجِ نفس",
    "meaning": "سانس کی لہر",
    "chapter": 26,
    "chapterTitle": "جنہیں میں ڈھونڈتا تھا آسمانوں میں زمینوں میں",
    "poet": "علامہ اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "اہلِ دل",
    "meaning": "باطنی طور پر روشن لوگ، صاحبانِ دل",
    "chapter": 26,
    "chapterTitle": "جنہیں میں ڈھونڈتا تھا آسمانوں میں زمینوں میں",
    "poet": "علامہ اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "خرقہ پوش",
    "meaning": "پیوند لگا لباس پہننے والا، فقیر، درویش",
    "chapter": 26,
    "chapterTitle": "جنہیں میں ڈھونڈتا تھا آسمانوں میں زمینوں میں",
    "poet": "علامہ اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "ارادت",
    "meaning": "عقیدت، محبت",
    "chapter": 26,
    "chapterTitle": "جنہیں میں ڈھونڈتا تھا آسمانوں میں زمینوں میں",
    "poet": "علامہ اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "یدِ بیضا",
    "meaning": "روشن، چمکتا ہوا ہاتھ (حضرت موسیٰؑ کا معجزہ)",
    "chapter": 26,
    "chapterTitle": "جنہیں میں ڈھونڈتا تھا آسمانوں میں زمینوں میں",
    "poet": "علامہ اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "مے",
    "meaning": "شراب",
    "chapter": 26,
    "chapterTitle": "جنہیں میں ڈھونڈتا تھا آسمانوں میں زمینوں میں",
    "poet": "علامہ اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "آبگینہ",
    "meaning": "شیشے کا برتن",
    "chapter": 26,
    "chapterTitle": "جنہیں میں ڈھونڈتا تھا آسمانوں میں زمینوں میں",
    "poet": "علامہ اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "باریک بین",
    "meaning": "گہری نظر رکھنے والا، دقیق نظر",
    "chapter": 26,
    "chapterTitle": "جنہیں میں ڈھونڈتا تھا آسمانوں میں زمینوں میں",
    "poet": "علامہ اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "چرچہ",
    "meaning": "تذکرہ، بات چیت",
    "chapter": 26,
    "chapterTitle": "جنہیں میں ڈھونڈتا تھا آسمانوں میں زمینوں میں",
    "poet": "علامہ اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "قرینہ",
    "meaning": "طریقہ، سلیقہ",
    "chapter": 26,
    "chapterTitle": "جنہیں میں ڈھونڈتا تھا آسمانوں میں زمینوں میں",
    "poet": "علامہ اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "نکتہ چیں",
    "meaning": "عیب جو، تنقید کرنے والا",
    "chapter": 26,
    "chapterTitle": "جنہیں میں ڈھونڈتا تھا آسمانوں میں زمینوں میں",
    "poet": "علامہ اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "صد شکر",
    "meaning": "بہت شکر، سو بار شکر",
    "chapter": 27,
    "chapterTitle": "کب یاد میں تیرا ساتھ نہیں، کب بات میں تیری بات نہیں",
    "poet": "فیض احمد فیض",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "ہجر",
    "meaning": "جدائی",
    "chapter": 27,
    "chapterTitle": "کب یاد میں تیرا ساتھ نہیں، کب بات میں تیری بات نہیں",
    "poet": "فیض احمد فیض",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "کوچۂ جاناں",
    "meaning": "محبوب کی گلی",
    "chapter": 27,
    "chapterTitle": "کب یاد میں تیرا ساتھ نہیں، کب بات میں تیری بات نہیں",
    "poet": "فیض احمد فیض",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "دل والو",
    "meaning": "اہلِ دل، عاشق لوگ",
    "chapter": 27,
    "chapterTitle": "کب یاد میں تیرا ساتھ نہیں، کب بات میں تیری بات نہیں",
    "poet": "فیض احمد فیض",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "دھج",
    "meaning": "انداز، شان و شوکت",
    "chapter": 27,
    "chapterTitle": "کب یاد میں تیرا ساتھ نہیں، کب بات میں تیری بات نہیں",
    "poet": "فیض احمد فیض",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "مقتل",
    "meaning": "قتل گاہ، جہاں سزائے موت دی جائے",
    "chapter": 27,
    "chapterTitle": "کب یاد میں تیرا ساتھ نہیں، کب بات میں تیری بات نہیں",
    "poet": "فیض احمد فیض",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "سلامت",
    "meaning": "قائم، محفوظ",
    "chapter": 27,
    "chapterTitle": "کب یاد میں تیرا ساتھ نہیں، کب بات میں تیری بات نہیں",
    "poet": "فیض احمد فیض",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "میدانِ وفا",
    "meaning": "محبت اور وفاداری کا میدان",
    "chapter": 27,
    "chapterTitle": "کب یاد میں تیرا ساتھ نہیں، کب بات میں تیری بات نہیں",
    "poet": "فیض احمد فیض",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "دربار",
    "meaning": "شاہی عدالت، دفتر",
    "chapter": 27,
    "chapterTitle": "کب یاد میں تیرا ساتھ نہیں، کب بات میں تیری بات نہیں",
    "poet": "فیض احمد فیض",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "نام و نسب",
    "meaning": "خاندان اور نسب کی پہچان",
    "chapter": 27,
    "chapterTitle": "کب یاد میں تیرا ساتھ نہیں، کب بات میں تیری بات نہیں",
    "poet": "فیض احمد فیض",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "بازی",
    "meaning": "کھیل، داؤ",
    "chapter": 27,
    "chapterTitle": "کب یاد میں تیرا ساتھ نہیں، کب بات میں تیری بات نہیں",
    "poet": "فیض احمد فیض",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "مات",
    "meaning": "شکست، ہار",
    "chapter": 27,
    "chapterTitle": "کب یاد میں تیرا ساتھ نہیں، کب بات میں تیری بات نہیں",
    "poet": "فیض احمد فیض",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "دریا",
    "meaning": "ندی، پانی کا بہاؤ",
    "chapter": 28,
    "chapterTitle": "کون کہتا ہے کہ موت آئی تو مر جاؤں گا",
    "poet": "احمد ندیم قاسمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "اترنا",
    "meaning": "داخل ہونا، شامل ہو جانا",
    "chapter": 28,
    "chapterTitle": "کون کہتا ہے کہ موت آئی تو مر جاؤں گا",
    "poet": "احمد ندیم قاسمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "کدھر",
    "meaning": "کس طرف",
    "chapter": 28,
    "chapterTitle": "کون کہتا ہے کہ موت آئی تو مر جاؤں گا",
    "poet": "احمد ندیم قاسمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "گِھرنا",
    "meaning": "گھر جانا، محصور ہو جانا",
    "chapter": 28,
    "chapterTitle": "کون کہتا ہے کہ موت آئی تو مر جاؤں گا",
    "poet": "احمد ندیم قاسمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "صحرا",
    "meaning": "ریگستان، ویرانہ",
    "chapter": 28,
    "chapterTitle": "کون کہتا ہے کہ موت آئی تو مر جاؤں گا",
    "poet": "احمد ندیم قاسمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "بکھرنا",
    "meaning": "منتشر ہو جانا",
    "chapter": 28,
    "chapterTitle": "کون کہتا ہے کہ موت آئی تو مر جاؤں گا",
    "poet": "احمد ندیم قاسمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "پہلو",
    "meaning": "ساتھ، برابر کی جگہ",
    "chapter": 28,
    "chapterTitle": "کون کہتا ہے کہ موت آئی تو مر جاؤں گا",
    "poet": "احمد ندیم قاسمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "مسافر",
    "meaning": "پردیسی، راہ گیر",
    "chapter": 28,
    "chapterTitle": "کون کہتا ہے کہ موت آئی تو مر جاؤں گا",
    "poet": "احمد ندیم قاسمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "سایۂ ابر",
    "meaning": "بادل کا سایہ",
    "chapter": 28,
    "chapterTitle": "کون کہتا ہے کہ موت آئی تو مر جاؤں گا",
    "poet": "احمد ندیم قاسمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "مانند",
    "meaning": "کی طرح، جیسا",
    "chapter": 28,
    "chapterTitle": "کون کہتا ہے کہ موت آئی تو مر جاؤں گا",
    "poet": "احمد ندیم قاسمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "پیمانِ وفا",
    "meaning": "وفاداری کا وعدہ",
    "chapter": 28,
    "chapterTitle": "کون کہتا ہے کہ موت آئی تو مر جاؤں گا",
    "poet": "احمد ندیم قاسمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "راہ کی دیوار",
    "meaning": "راستے کی رکاوٹ",
    "chapter": 28,
    "chapterTitle": "کون کہتا ہے کہ موت آئی تو مر جاؤں گا",
    "poet": "احمد ندیم قاسمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "چارہ ساز",
    "meaning": "علاج کرنے والا، مسیحا",
    "chapter": 28,
    "chapterTitle": "کون کہتا ہے کہ موت آئی تو مر جاؤں گا",
    "poet": "احمد ندیم قاسمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "معیار",
    "meaning": "پیمانہ، طرزِ فکر",
    "chapter": 28,
    "chapterTitle": "کون کہتا ہے کہ موت آئی تو مر جاؤں گا",
    "poet": "احمد ندیم قاسمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "سنورنا",
    "meaning": "بہتر ہونا، نکھرنا",
    "chapter": 28,
    "chapterTitle": "کون کہتا ہے کہ موت آئی تو مر جاؤں گا",
    "poet": "احمد ندیم قاسمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "شمع",
    "meaning": "موم بتی",
    "chapter": 28,
    "chapterTitle": "کون کہتا ہے کہ موت آئی تو مر جاؤں گا",
    "poet": "احمد ندیم قاسمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "ندیمؔ",
    "meaning": "شاعر کا تخلص",
    "chapter": 28,
    "chapterTitle": "کون کہتا ہے کہ موت آئی تو مر جاؤں گا",
    "poet": "احمد ندیم قاسمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "صبح کرنا",
    "meaning": "رات کاٹنا، روشنی پھیلانا",
    "chapter": 28,
    "chapterTitle": "کون کہتا ہے کہ موت آئی تو مر جاؤں گا",
    "poet": "احمد ندیم قاسمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "منزلِ شب",
    "meaning": "رات کی منزل، رات کا سفر",
    "chapter": 29,
    "chapterTitle": "سفرِ منزلِ شب یاد نہیں",
    "poet": "ناصر کاظمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "رخصت",
    "meaning": "جدائی، الوداع",
    "chapter": 29,
    "chapterTitle": "سفرِ منزلِ شب یاد نہیں",
    "poet": "ناصر کاظمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "اوّلیں",
    "meaning": "پہلی",
    "chapter": 29,
    "chapterTitle": "سفرِ منزلِ شب یاد نہیں",
    "poet": "ناصر کاظمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "قُرب",
    "meaning": "قربت، نزدیکی",
    "chapter": 29,
    "chapterTitle": "سفرِ منزلِ شب یاد نہیں",
    "poet": "ناصر کاظمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "سرشاری",
    "meaning": "مستی، بے خودی",
    "chapter": 29,
    "chapterTitle": "سفرِ منزلِ شب یاد نہیں",
    "poet": "ناصر کاظمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "ارماں",
    "meaning": "خواہشیں، تمنائیں",
    "chapter": 29,
    "chapterTitle": "سفرِ منزلِ شب یاد نہیں",
    "poet": "ناصر کاظمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "چبھن",
    "meaning": "کانٹے جیسی تکلیف، ٹیس",
    "chapter": 29,
    "chapterTitle": "سفرِ منزلِ شب یاد نہیں",
    "poet": "ناصر کاظمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "طلب",
    "meaning": "خواہش، چاہت",
    "chapter": 29,
    "chapterTitle": "سفرِ منزلِ شب یاد نہیں",
    "poet": "ناصر کاظمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "شبنم",
    "meaning": "اوس کا قطرہ",
    "chapter": 29,
    "chapterTitle": "سفرِ منزلِ شب یاد نہیں",
    "poet": "ناصر کاظمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "عجب",
    "meaning": "حیرت انگیز، انوکھی",
    "chapter": 29,
    "chapterTitle": "سفرِ منزلِ شب یاد نہیں",
    "poet": "ناصر کاظمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "ویراں",
    "meaning": "اجاڑ، سنسان",
    "chapter": 29,
    "chapterTitle": "سفرِ منزلِ شب یاد نہیں",
    "poet": "ناصر کاظمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "گزر گاہِ خیال",
    "meaning": "خیال کا راستہ، سوچوں کی راہ گزر",
    "chapter": 29,
    "chapterTitle": "سفرِ منزلِ شب یاد نہیں",
    "poet": "ناصر کاظمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "عارض",
    "meaning": "رخسار، گال",
    "chapter": 29,
    "chapterTitle": "سفرِ منزلِ شب یاد نہیں",
    "poet": "ناصر کاظمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "دیار",
    "meaning": "بستیاں، مقامات",
    "chapter": 29,
    "chapterTitle": "سفرِ منزلِ شب یاد نہیں",
    "poet": "ناصر کاظمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "رشتۂ جاں",
    "meaning": "جان کا رشتہ، جان سے جڑا تعلق",
    "chapter": 29,
    "chapterTitle": "سفرِ منزلِ شب یاد نہیں",
    "poet": "ناصر کاظمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "احباب",
    "meaning": "دوست، جمع ہے حبیب کی",
    "chapter": 29,
    "chapterTitle": "سفرِ منزلِ شب یاد نہیں",
    "poet": "ناصر کاظمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "سیرِ چراغاں",
    "meaning": "چراغوں کی روشنی میں سیر، چراغوں کا میلہ",
    "chapter": 29,
    "chapterTitle": "سفرِ منزلِ شب یاد نہیں",
    "poet": "ناصر کاظمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "سبب",
    "meaning": "وجہ، علت",
    "chapter": 29,
    "chapterTitle": "سفرِ منزلِ شب یاد نہیں",
    "poet": "ناصر کاظمی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "صحن",
    "meaning": "گھر کا کھلا حصہ، آنگن",
    "chapter": 30,
    "chapterTitle": "آکے پتھر تو مرے صحن میں دو چار گرے",
    "poet": "شکیب جلالی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "پس دیوار",
    "meaning": "دیوار کے پیچھے",
    "chapter": 30,
    "chapterTitle": "آکے پتھر تو مرے صحن میں دو چار گرے",
    "poet": "شکیب جلالی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "گرنا",
    "meaning": "نیچے آ گرنا",
    "chapter": 30,
    "chapterTitle": "آکے پتھر تو مرے صحن میں دو چار گرے",
    "poet": "شکیب جلالی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "قدم",
    "meaning": "پاؤں، چلنے کا عمل",
    "chapter": 30,
    "chapterTitle": "آکے پتھر تو مرے صحن میں دو چار گرے",
    "poet": "شکیب جلالی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "سایہ",
    "meaning": "پرچھائیں",
    "chapter": 30,
    "chapterTitle": "آکے پتھر تو مرے صحن میں دو چار گرے",
    "poet": "شکیب جلالی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "گروں",
    "meaning": "میں گر جاؤں",
    "chapter": 30,
    "chapterTitle": "آکے پتھر تو مرے صحن میں دو چار گرے",
    "poet": "شکیب جلالی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "تیرگی",
    "meaning": "اندھیرا",
    "chapter": 30,
    "chapterTitle": "آکے پتھر تو مرے صحن میں دو چار گرے",
    "poet": "شکیب جلالی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "اجالا",
    "meaning": "روشنی",
    "chapter": 30,
    "chapterTitle": "آکے پتھر تو مرے صحن میں دو چار گرے",
    "poet": "شکیب جلالی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "خطوط",
    "meaning": "لکیریں، نشان",
    "chapter": 30,
    "chapterTitle": "آکے پتھر تو مرے صحن میں دو چار گرے",
    "poet": "شکیب جلالی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "بے کار",
    "meaning": "فضول، بے فائدہ",
    "chapter": 30,
    "chapterTitle": "آکے پتھر تو مرے صحن میں دو چار گرے",
    "poet": "شکیب جلالی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "در و بام",
    "meaning": "دروازے اور چھت، یعنی گھر",
    "chapter": 30,
    "chapterTitle": "آکے پتھر تو مرے صحن میں دو چار گرے",
    "poet": "شکیب جلالی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "لرزنا",
    "meaning": "کانپنا، ڈر جانا",
    "chapter": 30,
    "chapterTitle": "آکے پتھر تو مرے صحن میں دو چار گرے",
    "poet": "شکیب جلالی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "ہمسایہ",
    "meaning": "پڑوسی",
    "chapter": 30,
    "chapterTitle": "آکے پتھر تو مرے صحن میں دو چار گرے",
    "poet": "شکیب جلالی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "دور",
    "meaning": "دھاگا، مانجھا، جس سے پتنگ اڑائی جاتی ہے",
    "chapter": 30,
    "chapterTitle": "آکے پتھر تو مرے صحن میں دو چار گرے",
    "poet": "شکیب جلالی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "گھڑی",
    "meaning": "وقت کا لمحہ",
    "chapter": 30,
    "chapterTitle": "آکے پتھر تو مرے صحن میں دو چار گرے",
    "poet": "شکیب جلالی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "لٹکی ہوئی تلوار",
    "meaning": "سر پر معلق خطرہ",
    "chapter": 30,
    "chapterTitle": "آکے پتھر تو مرے صحن میں دو چار گرے",
    "poet": "شکیب جلالی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "بلندی",
    "meaning": "اونچائی",
    "chapter": 30,
    "chapterTitle": "آکے پتھر تو مرے صحن میں دو چار گرے",
    "poet": "شکیب جلالی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "دستار",
    "meaning": "پگڑی، عزت کی علامت",
    "chapter": 30,
    "chapterTitle": "آکے پتھر تو مرے صحن میں دو چار گرے",
    "poet": "شکیب جلالی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "شکیبؔ",
    "meaning": "شاعر کا تخلص",
    "chapter": 30,
    "chapterTitle": "آکے پتھر تو مرے صحن میں دو چار گرے",
    "poet": "شکیب جلالی",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "لب کشا",
    "meaning": "بولنا، آواز اٹھانا",
    "chapter": 31,
    "chapterTitle": "لب کشا لوگ ہیں، سرکار کو کیا بولنا ہے",
    "poet": "احمد فراز",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "سرکار",
    "meaning": "حکومت",
    "chapter": 31,
    "chapterTitle": "لب کشا لوگ ہیں، سرکار کو کیا بولنا ہے",
    "poet": "احمد فراز",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "لہو",
    "meaning": "خون",
    "chapter": 31,
    "chapterTitle": "لب کشا لوگ ہیں، سرکار کو کیا بولنا ہے",
    "poet": "احمد فراز",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "بکنا",
    "meaning": "فروخت ہونا، ضمیر بیچنا",
    "chapter": 31,
    "chapterTitle": "لب کشا لوگ ہیں، سرکار کو کیا بولنا ہے",
    "poet": "احمد فراز",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "خریدار",
    "meaning": "فروخت ہونے والوں کو خریدنے والا",
    "chapter": 31,
    "chapterTitle": "لب کشا لوگ ہیں، سرکار کو کیا بولنا ہے",
    "poet": "احمد فراز",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "یار",
    "meaning": "دوست",
    "chapter": 31,
    "chapterTitle": "لب کشا لوگ ہیں، سرکار کو کیا بولنا ہے",
    "poet": "احمد فراز",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "گواہی",
    "meaning": "شہادت، عدالت میں بیان",
    "chapter": 31,
    "chapterTitle": "لب کشا لوگ ہیں، سرکار کو کیا بولنا ہے",
    "poet": "احمد فراز",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "گوش بر آواز",
    "meaning": "کان لگائے، منتظر",
    "chapter": 31,
    "chapterTitle": "لب کشا لوگ ہیں، سرکار کو کیا بولنا ہے",
    "poet": "احمد فراز",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "چراغ",
    "meaning": "علامتی طور پر شاعر خود",
    "chapter": 31,
    "chapterTitle": "لب کشا لوگ ہیں، سرکار کو کیا بولنا ہے",
    "poet": "احمد فراز",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "ہوا",
    "meaning": "علامتی طور پر آمرانہ نظامِ حکومت",
    "chapter": 31,
    "chapterTitle": "لب کشا لوگ ہیں، سرکار کو کیا بولنا ہے",
    "poet": "احمد فراز",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "گنہگار",
    "meaning": "گناہ کرنے والا",
    "chapter": 31,
    "chapterTitle": "لب کشا لوگ ہیں، سرکار کو کیا بولنا ہے",
    "poet": "احمد فراز",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "سرِ دار",
    "meaning": "سولی پر",
    "chapter": 31,
    "chapterTitle": "لب کشا لوگ ہیں، سرکار کو کیا بولنا ہے",
    "poet": "احمد فراز",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "خلقت",
    "meaning": "لوگ",
    "chapter": 31,
    "chapterTitle": "لب کشا لوگ ہیں، سرکار کو کیا بولنا ہے",
    "poet": "احمد فراز",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "شاہ",
    "meaning": "بادشاہ، حاکم",
    "chapter": 31,
    "chapterTitle": "لب کشا لوگ ہیں، سرکار کو کیا بولنا ہے",
    "poet": "احمد فراز",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "فرمان",
    "meaning": "حکم",
    "chapter": 31,
    "chapterTitle": "لب کشا لوگ ہیں، سرکار کو کیا بولنا ہے",
    "poet": "احمد فراز",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "اسرار",
    "meaning": "راز",
    "chapter": 31,
    "chapterTitle": "لب کشا لوگ ہیں، سرکار کو کیا بولنا ہے",
    "poet": "احمد فراز",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "پسِ پردہ",
    "meaning": "پردے کے پیچھے",
    "chapter": 31,
    "chapterTitle": "لب کشا لوگ ہیں، سرکار کو کیا بولنا ہے",
    "poet": "احمد فراز",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "تماشا گر",
    "meaning": "تماشا لگانے والا، ہدایتکار",
    "chapter": 31,
    "chapterTitle": "لب کشا لوگ ہیں، سرکار کو کیا بولنا ہے",
    "poet": "احمد فراز",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "کردار",
    "meaning": "اداکار",
    "chapter": 31,
    "chapterTitle": "لب کشا لوگ ہیں، سرکار کو کیا بولنا ہے",
    "poet": "احمد فراز",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "دربار",
    "meaning": "شاہی مجلس",
    "chapter": 31,
    "chapterTitle": "لب کشا لوگ ہیں، سرکار کو کیا بولنا ہے",
    "poet": "احمد فراز",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "مصاحب",
    "meaning": "ساتھی، درباری",
    "chapter": 31,
    "chapterTitle": "لب کشا لوگ ہیں، سرکار کو کیا بولنا ہے",
    "poet": "احمد فراز",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "طرف دار",
    "meaning": "حمایتی",
    "chapter": 31,
    "chapterTitle": "لب کشا لوگ ہیں، سرکار کو کیا بولنا ہے",
    "poet": "احمد فراز",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "شراکت",
    "meaning": "حصہ داری، ساجھا",
    "chapter": 32,
    "chapterTitle": "مل کے بیٹھے نہیں، خوابوں میں شراکت نہیں کی",
    "poet": "ظفر اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "رشتہ",
    "meaning": "تعلق، ناتا",
    "chapter": 32,
    "chapterTitle": "مل کے بیٹھے نہیں، خوابوں میں شراکت نہیں کی",
    "poet": "ظفر اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "شریف",
    "meaning": "شائستہ، باوقار",
    "chapter": 32,
    "chapterTitle": "مل کے بیٹھے نہیں، خوابوں میں شراکت نہیں کی",
    "poet": "ظفر اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "دشت",
    "meaning": "صحرا، ویرانہ",
    "chapter": 32,
    "chapterTitle": "مل کے بیٹھے نہیں، خوابوں میں شراکت نہیں کی",
    "poet": "ظفر اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "خاک اڑانا",
    "meaning": "دیوانہ وار مارا مارا پھرنا",
    "chapter": 32,
    "chapterTitle": "مل کے بیٹھے نہیں، خوابوں میں شراکت نہیں کی",
    "poet": "ظفر اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "وحشت",
    "meaning": "دیوانگی، جنون",
    "chapter": 32,
    "chapterTitle": "مل کے بیٹھے نہیں، خوابوں میں شراکت نہیں کی",
    "poet": "ظفر اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "سلوک",
    "meaning": "برتاؤ، رویہ",
    "chapter": 32,
    "chapterTitle": "مل کے بیٹھے نہیں، خوابوں میں شراکت نہیں کی",
    "poet": "ظفر اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "رعایت",
    "meaning": "نرمی، خصوصی چھوٹ",
    "chapter": 32,
    "chapterTitle": "مل کے بیٹھے نہیں، خوابوں میں شراکت نہیں کی",
    "poet": "ظفر اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "ارادہ",
    "meaning": "نیت، خواہش",
    "chapter": 32,
    "chapterTitle": "مل کے بیٹھے نہیں، خوابوں میں شراکت نہیں کی",
    "poet": "ظفر اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "ہمت",
    "meaning": "حوصلہ، جرات",
    "chapter": 32,
    "chapterTitle": "مل کے بیٹھے نہیں، خوابوں میں شراکت نہیں کی",
    "poet": "ظفر اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "دانستہ",
    "meaning": "جان بوجھ کر",
    "chapter": 32,
    "chapterTitle": "مل کے بیٹھے نہیں، خوابوں میں شراکت نہیں کی",
    "poet": "ظفر اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "حمایت",
    "meaning": "حق میں بات، طرف داری",
    "chapter": 32,
    "chapterTitle": "مل کے بیٹھے نہیں، خوابوں میں شراکت نہیں کی",
    "poet": "ظفر اقبال",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "رضا",
    "meaning": "مرضی، منظوری",
    "chapter": 33,
    "chapterTitle": "نہ سہی کچھ مگر اتنا تو کیا کرتے تھے",
    "poet": "شہزاد احمد",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "اصرار",
    "meaning": "ضد، زور دینا",
    "chapter": 33,
    "chapterTitle": "نہ سہی کچھ مگر اتنا تو کیا کرتے تھے",
    "poet": "شہزاد احمد",
    "type": "غزل",
    "source": "chapter"
  },
  {
    "word": "گردن زدنی",
    "meaning": "قتل کے قابل، سزائے موت کا مستحق",
    "chapter": 33,
    "chapterTitle": "نہ سہی کچھ مگر اتنا تو کیا کرتے تھے",
    "poet": "شہزاد احمد",
    "type": "غزل",
    "source": "chapter"
  }
];
