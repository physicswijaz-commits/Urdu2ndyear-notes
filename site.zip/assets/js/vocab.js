/* ==========================================================================
   ذخیرۂ الفاظ — Vocabulary Bank page logic (vocabulary.html)
   - VOCAB_CORE (from vocab-data.js) = تمام اسباق سے خودکار جمع شدہ الفاظ
   - localStorage 'myVocab' = طالب علم کے اپنے شامل کردہ الفاظ (مثال کے ساتھ)
   ========================================================================== */
document.addEventListener('DOMContentLoaded', () => {
  if (typeof VOCAB_CORE === 'undefined') return;

  const STORAGE_KEY = 'myVocab';

  function loadMine() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'); }
    catch (e) { return []; }
  }
  function saveMine(list) { localStorage.setItem(STORAGE_KEY, JSON.stringify(list)); }

  function allEntries() {
    const mine = loadMine().map((w) => ({ ...w, source: 'mine' }));
    return VOCAB_CORE.concat(mine);
  }

  let state = { search: '', filter: 'all' };

  const listEl = document.getElementById('vb-list');
  const emptyEl = document.getElementById('vb-empty');
  const filtersEl = document.getElementById('vb-filters');
  const searchEl = document.getElementById('vb-search');

  /* ---------- Render ---------- */
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function tagLabel(e) {
    if (e.source === 'mine') return '★ میرا لفظ';
    const parts = [];
    if (e.type) parts.push(e.type);
    if (e.chapter) parts.push('سبق ' + e.chapter);
    return parts.join(' · ');
  }

  function render() {
    const entries = allEntries();
    const q = state.search.trim().toLowerCase();

    let filtered = entries.filter((e) => {
      if (state.filter === 'mine' && e.source !== 'mine') return false;
      if (['نثر', 'نظم', 'غزل'].includes(state.filter)) {
        if (e.source === 'mine' || e.type !== state.filter) return false;
      }
      if (q && !(e.word.toLowerCase().includes(q) || e.meaning.toLowerCase().includes(q))) return false;
      return true;
    });

    // Urdu-aware sort (falls back gracefully if localeCompare with 'ur' isn't supported)
    filtered.sort((a, b) => a.word.localeCompare(b.word, 'ur'));

    document.getElementById('vb-stat-total').textContent = entries.length;
    document.getElementById('vb-stat-chapters').textContent = new Set(VOCAB_CORE.map((e) => e.chapter)).size;
    document.getElementById('vb-stat-mine').textContent = loadMine().length;

    if (!filtered.length) {
      listEl.innerHTML = '';
      emptyEl.style.display = 'block';
      return;
    }
    emptyEl.style.display = 'none';

    listEl.innerHTML = filtered.map((e) => {
      const tag = '<span class="vb-tag' + (e.source === 'mine' ? ' mine' : '') + '">' + escapeHtml(tagLabel(e)) + '</span>';
      const example = e.example
        ? '<div class="vb-example">' + escapeHtml(e.example) + '</div>'
        : '';
      const deleteBtn = e.source === 'mine'
        ? '<div class="vb-card-actions"><button data-delete="' + e.id + '"><i data-lucide="trash-2"></i> حذف کریں</button></div>'
        : '';
      return (
        '<div class="vb-card">' +
          '<div class="vb-card-top"><span class="vb-word">' + escapeHtml(e.word) + '</span>' + tag + '</div>' +
          '<div class="vb-meaning">' + escapeHtml(e.meaning) + '</div>' +
          example +
          deleteBtn +
        '</div>'
      );
    }).join('');

    if (window.lucide) lucide.createIcons();

    listEl.querySelectorAll('[data-delete]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-delete');
        const mine = loadMine().filter((w) => String(w.id) !== String(id));
        saveMine(mine);
        render();
      });
    });
  }

  /* ---------- Search + filters ---------- */
  searchEl.addEventListener('input', () => { state.search = searchEl.value; render(); });
  filtersEl.addEventListener('click', (e) => {
    const btn = e.target.closest('.vb-filter-chip');
    if (!btn) return;
    filtersEl.querySelectorAll('.vb-filter-chip').forEach((c) => c.classList.remove('active'));
    btn.classList.add('active');
    state.filter = btn.dataset.filter;
    render();
  });

  /* ---------- Add-word modal ---------- */
  const modalBackdrop = document.getElementById('vb-modal-backdrop');
  const openBtn = document.getElementById('vb-add-open');
  const cancelBtn = document.getElementById('vb-modal-cancel');
  const saveBtn = document.getElementById('vb-modal-save');
  const wordInput = document.getElementById('vb-input-word');
  const meaningInput = document.getElementById('vb-input-meaning');
  const exampleInput = document.getElementById('vb-input-example');

  function openModal() {
    wordInput.value = ''; meaningInput.value = ''; exampleInput.value = '';
    modalBackdrop.classList.add('open');
    setTimeout(() => wordInput.focus(), 50);
  }
  function closeModal() { modalBackdrop.classList.remove('open'); }

  openBtn.addEventListener('click', openModal);
  cancelBtn.addEventListener('click', closeModal);
  modalBackdrop.addEventListener('click', (e) => { if (e.target === modalBackdrop) closeModal(); });

  /* ---------- Bulk-paste modal ---------- */
  const bulkBackdrop = document.getElementById('vb-bulk-modal-backdrop');
  const bulkOpenBtn = document.getElementById('vb-bulk-open');
  const bulkCancelBtn = document.getElementById('vb-bulk-cancel');
  const bulkSaveBtn = document.getElementById('vb-bulk-save');
  const bulkInput = document.getElementById('vb-bulk-input');
  const bulkPreview = document.getElementById('vb-bulk-preview');

  /* Parses lines like:
       تجسیم: کسی غیر مادی چیز کو جسمانی شکل دینا
       o **تلمیح:** کسی مشہور واقعے کی طرف اشارہ
       استعارہ: تشبیہ || اس کا دل پتھر ہے
     Skips section headings and blank lines. */
  function parseBulkText(text) {
    const lines = text.split('\n');
    const parsed = [];
    lines.forEach((raw) => {
      let line = raw.trim();
      if (!line) return;
      line = line.replace(/^[-•*o○►▸]\s+/, '').replace(/^\d+[\.\)]\s+/, '');
      line = line.replace(/\*\*/g, '');
      const colonIdx = line.search(/[:：]/);
      if (colonIdx === -1) return;
      const wordPart = line.slice(0, colonIdx).trim();
      let restPart = line.slice(colonIdx + 1).trim();
      if (!wordPart || !restPart) return;
      if (wordPart.split(/\s+/).length > 6) return; // likely a heading/sentence, not a term
      let example = '';
      const exampleSplit = restPart.split('||');
      if (exampleSplit.length > 1) {
        restPart = exampleSplit[0].trim();
        example = exampleSplit.slice(1).join('||').trim();
      }
      if (!restPart) return;
      parsed.push({ word: wordPart, meaning: restPart, example });
    });
    return parsed;
  }

  function updateBulkPreview() {
    const parsed = parseBulkText(bulkInput.value);
    bulkPreview.innerHTML = parsed.length
      ? '<b>' + parsed.length + '</b> لفظ ملے — عنوانات اور خالی سطریں خودبخود نظرانداز ہو گئیں۔'
      : 'اوپر اپنی فہرست پیسٹ کریں — ہر سطر میں ایک لفظ۔';
  }

  function openBulkModal() {
    bulkInput.value = '';
    updateBulkPreview();
    bulkBackdrop.classList.add('open');
    setTimeout(() => bulkInput.focus(), 50);
  }
  function closeBulkModal() { bulkBackdrop.classList.remove('open'); }

  bulkOpenBtn.addEventListener('click', openBulkModal);
  bulkCancelBtn.addEventListener('click', closeBulkModal);
  bulkBackdrop.addEventListener('click', (e) => { if (e.target === bulkBackdrop) closeBulkModal(); });
  bulkInput.addEventListener('input', updateBulkPreview);

  bulkSaveBtn.addEventListener('click', () => {
    const parsed = parseBulkText(bulkInput.value);
    if (!parsed.length) { closeBulkModal(); return; }
    const mine = loadMine();
    const existing = new Set(mine.map((w) => w.word.toLowerCase()));
    let added = 0;
    parsed.forEach((w, i) => {
      if (existing.has(w.word.toLowerCase())) return;
      mine.push({ id: Date.now() + i, word: w.word, meaning: w.meaning, example: w.example, addedAt: new Date().toISOString() });
      existing.add(w.word.toLowerCase());
      added++;
    });
    saveMine(mine);
    closeBulkModal();
    filtersEl.querySelectorAll('.vb-filter-chip').forEach((c) => c.classList.remove('active'));
    filtersEl.querySelector('[data-filter="mine"]').classList.add('active');
    state.filter = 'mine';
    render();
  });

  saveBtn.addEventListener('click', () => {
    const word = wordInput.value.trim();
    const meaning = meaningInput.value.trim();
    const example = exampleInput.value.trim();
    if (!word || !meaning) {
      wordInput.style.borderColor = word ? '' : 'var(--danger, #C0392B)';
      meaningInput.style.borderColor = meaning ? '' : 'var(--danger, #C0392B)';
      return;
    }
    const mine = loadMine();
    mine.push({ id: Date.now(), word, meaning, example, addedAt: new Date().toISOString() });
    saveMine(mine);
    closeModal();
    filtersEl.querySelectorAll('.vb-filter-chip').forEach((c) => c.classList.remove('active'));
    filtersEl.querySelector('[data-filter="mine"]').classList.add('active');
    state.filter = 'mine';
    render();
  });

  render();

  /* ---------- Export / Import backup ---------- */
  document.getElementById('vb-export').addEventListener('click', () => {
    const mine = loadMine();
    const blob = new Blob([JSON.stringify({ exportedAt: new Date().toISOString(), words: mine }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const stamp = new Date().toISOString().slice(0, 10);
    a.href = url;
    a.download = 'meray-alfaz-backup-' + stamp + '.json';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  });

  const importInput = document.getElementById('vb-import-file');
  document.getElementById('vb-import').addEventListener('click', () => importInput.click());
  importInput.addEventListener('change', () => {
    const file = importInput.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        const incoming = Array.isArray(data) ? data : (Array.isArray(data.words) ? data.words : null);
        if (!incoming) throw new Error('Unrecognised backup format');
        const mine = loadMine();
        const existing = new Set(mine.map((w) => w.word.toLowerCase()));
        let added = 0;
        incoming.forEach((w, i) => {
          if (!w || !w.word || !w.meaning) return;
          if (existing.has(String(w.word).toLowerCase())) return;
          mine.push({ id: Date.now() + i, word: w.word, meaning: w.meaning, example: w.example || '', addedAt: w.addedAt || new Date().toISOString() });
          existing.add(String(w.word).toLowerCase());
          added++;
        });
        saveMine(mine);
        render();
        alert(added + ' لفظ درآمد ہوئے' + (incoming.length - added > 0 ? ' (' + (incoming.length - added) + ' پہلے سے موجود تھے، چھوڑ دیے گئے)' : '') + '۔');
      } catch (e) {
        alert('یہ فائل نہیں پڑھی جا سکی — یقینی بنائیں کہ یہ اسی صفحے سے برآمد کردہ بیک اپ ہے۔');
      }
      importInput.value = '';
    };
    reader.readAsText(file);
  });
});
