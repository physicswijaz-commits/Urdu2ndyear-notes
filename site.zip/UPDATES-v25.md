# v25 — grey & white + Mutalea-Quran-style chapter cards
- Palette: neutral grey/white (light), charcoal (dark), cool grey (sepia); no pattern, no gold/green accents (green only for "read" progress).
- Home: each chapter is a big centered card with progress bar; tap to expand → choose سبق or مشق → "کھولیں".
- Side gutters reduced to 12px on all pages.
- Cache v25.
