# اردو نوٹس — v22 updates

## Fixes
- Icon library pinned to `lucide@0.468.0` on all 36 pages (was `@latest`, which can break icons without warning) and added to the offline precache.
- Contrast: gold due-badge on flashcards; white-on-mint buttons/chips in dark theme (vocabulary & flashcards) now readable.
- No text under 11px (tab-bar labels, stats, tags, answer labels, ring label).
- Service worker cache bumped to `v22`; `extras.js` added to precache.

## New (all in `assets/js/extras.js` + a block at the end of `style.css`)
- "نیا ورژن آ گیا ہے" notice with a refresh button after an update.
- Home: exam-date card with day countdown; "آج کی دہرائی" card (flashcard words due + lessons with Q&A still marked "سیکھ رہا ہوں"); install-app, share-with-friends, progress backup and restore buttons.
- Lessons: reading-time chip, print / save-as-PDF button, "غلطی بتائیں" WhatsApp link (number set at the top of extras.js: `CONTACT_WA`).
- Print stylesheet hides menus and shows every answer.

## Notes for you
- The access gate in `index.html` only covers the home page; lesson pages (e.g. `nasr-1.html`) open directly without a key, and `VALID_KEYS` is readable in the page source. Fine for casual use, not for real protection.
- The upload contained a `MoonReader` folder (an epub and screenshots); it is not part of the site and was left out.
- Backup file excludes the unlock flag on purpose.
