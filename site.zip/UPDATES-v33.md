# v33
- Removed 'گروپ A/B' from the lesson header. Cache v33.
