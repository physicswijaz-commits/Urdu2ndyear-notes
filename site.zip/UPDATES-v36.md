# v36
- Exam date: home card only shows days left (tap opens the menu); the date is edited in the ≡ menu under سیٹنگز. Cache v36.
